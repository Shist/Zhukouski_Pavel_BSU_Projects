﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using CSDS.Core.Entities;

namespace CSDS.Core.Repositories
{
    public interface ITextRepository : IRepository<Text, Guid>
    {
        public (IEnumerable<Text>, int) PagingList(int offset, int pageSize,
            List<Expression<Func<Text, bool>>> predicateList = null,
            Func<IQueryable<Text>, IOrderedQueryable<Text>> orderBy = null,
            string includeProperties = "", bool track = true);
    }
}

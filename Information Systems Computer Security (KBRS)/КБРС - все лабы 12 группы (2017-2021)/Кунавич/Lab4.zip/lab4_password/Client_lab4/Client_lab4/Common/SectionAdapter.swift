

import Foundation
import UIKit

protocol SectionAdapter {
    var identifier: String { get }
    var count: Int { get }
    
    func createCell(forIndex index: Int) -> UITableViewCell
    func updateCell(_ cell: UITableViewCell, forIndex index: Int)
    func selected(atIndex index: Int)
}

import java.io.*;
import java.util.List;
import java.util.Map;

public class Vigner {

    //public static final String alphabet = new String("ABCDEFGHIJKLMNOPQRSTUVWXYZ ");

    protected static String password = "zevgenia";

    public static String encrypt(String input, String word) throws Exception {
        StringBuilder sb = new StringBuilder(input.toUpperCase());
        for (int i = 0, j = 0; i < sb.length(); i++, j = (j + 1) % word.length()) {
            sb.setCharAt(i, encryptChar(sb.charAt(i), word.charAt(j) - 'A'));
        }
        return sb.toString();
    }
    private static char encryptChar(char c, int length) {
        char res = c;
        length %= 26;

        if (c >= 'A' && c <= 'Z') {
            res = (char) ((res - 'A' + length + 26) % 26 + 'A');
        }
        return res;
    }


    private static String decode(String s, String key) throws Exception {
        StringBuilder sb = new StringBuilder(s.toUpperCase());
        for (int i = 0, j = 0; i < sb.length(); i++, j = (j + 1) % key.length()) {
            sb.setCharAt(i, encryptChar(sb.charAt(i), -(key.charAt(j) - 'A')));
        }
        return sb.toString();
    }


    public static void main(String args[]){
        String s = "";
        String res="";
        String res2="";
        try {
            s = Reader.ReadFromFile("start.txt");
        } catch (FileNotFoundException e){
            e.printStackTrace();
        }
        try{
          res = encrypt(s, password);
        } catch(Exception e){
            e.printStackTrace();
        }
        System.out.println(res);

        try{
            System.out.println();
            res2 = decode(res, password);
        } catch(Exception e){
            e.printStackTrace();
        }
        System.out.println(res2);

        try{
            Test test = new Test();
            test.testTextLengthByKasiskaTask3(s, "zevgenia",30, 0.4, 8);
            test.testKeywordLengthByKasiskaTask4(30, 0.4, 1000);
        } catch(Exception e){
            e.printStackTrace();
        }


    }
}

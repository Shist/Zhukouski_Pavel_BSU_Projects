

import UIKit

extension UITableView {
    
    func setAdapter(_ adapter: TableAdapter) {
        dataSource = adapter
        delegate = adapter
    }
    
}

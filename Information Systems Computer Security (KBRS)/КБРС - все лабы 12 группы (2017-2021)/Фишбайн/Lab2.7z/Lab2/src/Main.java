import java.util.Scanner;

import Server.Server;
import Client.Client;

/**
 * Стартовая точка программы. Содержит единственный метод main
 *
 * @author
 */
public class Main {

    /**
     * Спрашивает пользователя о режиме работы (сервер или клиент) и передаёт
     * управление соответствующему классу
     * @param args параметры командной строки
     */
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);

        System.out.println("Run program as Server or Client? (S / C)");
        while (true) {
            char answer = Character.toLowerCase(in.nextLine().charAt(0));
            if (answer == 's') {
                new Server();
                break;
            } else if (answer == 'c') {
                new Client();
                break;
            } else {
                System.out.println("Incorrect input. Try again.");
            }
        }
    }
}
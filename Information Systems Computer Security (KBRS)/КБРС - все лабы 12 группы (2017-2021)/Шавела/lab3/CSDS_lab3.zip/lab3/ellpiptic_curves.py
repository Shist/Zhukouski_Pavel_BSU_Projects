import hashlib
import random

sample = {
    "M": 211,
    "a": 0,
    "b": -4,
    "g": (2, 2),
    "n": 0
}

elliptic_curve = sample

my_points = []


def define_coefficients(M):
    elliptic_curve["M"] = M
    a, b = 0, 0
    while b < M:
        while a < M:
            if (4 * pow(a, 3) + 27 * pow(b, 2)) % M != 0:
                elliptic_curve["a"] = a
                elliptic_curve["b"] = b
                print("Coefficients:", a, b)
                return
            else:
                a += 1
        b += 1


def get_all_elements():
    x = 0
    while x < elliptic_curve["M"]:
        y = 0
        while y < elliptic_curve["M"]:
            if is_on_curve((x, y)):
                my_points.append((x, y))
            y += 1
        x += 1

    elliptic_curve["n"] = len(my_points) + 1


def extended_euclidean_algorithm(a, b):
    s, old_s = 0, 1
    t, old_t = 1, 0
    r, old_r = b, a

    while r != 0:
        quotient = old_r // r
        old_r, r = r, old_r - quotient * r
        old_s, s = s, old_s - quotient * s
        old_t, t = t, old_t - quotient * t

    return old_r, old_s, old_t


def mod_division(k, p):
    if k == 0:
        raise ZeroDivisionError('Деление на 0!!')

    if k < 0:
        return p - mod_division(-k, p)

    gcd, x, _ = extended_euclidean_algorithm(k, p)

    assert gcd == 1
    assert (k * x) % p == 1

    return x % p


def is_on_curve(point):
    if point is None:
        return True

    x, y = point
    return (y * y - x * x * x - elliptic_curve["a"] * x - elliptic_curve["b"]) % elliptic_curve["M"] == 0


def point_neg(point):
    assert is_on_curve(point)

    if point is None:
        return None

    x, y = point
    result = (x, -y % elliptic_curve["M"])

    assert is_on_curve(result)

    return result


def point_add(point1, point2):
    assert is_on_curve(point1)
    assert is_on_curve(point2)

    if point1 is None:
        return point2
    if point2 is None:
        return point1

    x1, y1 = point1
    x2, y2 = point2

    if x1 == x2 and y1 != y2:
        return None

    if x1 == x2:
        m = (3 * x1 * x1 + elliptic_curve["a"]) * mod_division(2 * y1, elliptic_curve["M"])
    else:
        m = (y1 - y2) * mod_division(x1 - x2, elliptic_curve["M"])

    x3 = m * m - x1 - x2
    y3 = y1 + m * (x3 - x1)
    result = (x3 % elliptic_curve["M"],
              -y3 % elliptic_curve["M"])

    assert is_on_curve(result)

    return result


def scalar_multiply(k, point):
    assert is_on_curve(point)

    if k % elliptic_curve["n"] == 0 or point is None:
        return None

    if k < 0:
        return scalar_multiply(-k, point_neg(point))

    result = None
    addend = point

    while k:
        if k & 1:
            result = point_add(result, addend)

        addend = point_add(addend, addend)

        k >>= 1

    assert is_on_curve(result)

    return result


def make_key_pair():
    private_key = random.randrange(1, elliptic_curve["n"])
    public_key = scalar_multiply(private_key, elliptic_curve["g"])

    return private_key, public_key


def hash_message(message):
    message_hash = hashlib.sha512(message).digest()
    e = int.from_bytes(message_hash, 'big')

    z = e >> (e.bit_length() - elliptic_curve["n"].bit_length())

    assert z.bit_length() <= elliptic_curve["n"].bit_length()

    return z


def sign_message(private_key, message):
    z = hash_message(message)

    r = 0
    s = 0

    while not r or not s:
        k = random.randrange(1, elliptic_curve["n"])
        x, _ = scalar_multiply(k, elliptic_curve["g"])

        r = x % elliptic_curve["n"]
        s = ((z + r * private_key) * mod_division(k, elliptic_curve["n"])) % elliptic_curve["n"]
    return r, s


def verify_signature(public_key, message, signature):
    z = hash_message(message)
    r, s = signature

    w = mod_division(s, elliptic_curve["n"])
    u1 = (z * w) % elliptic_curve["n"]
    u2 = (r * w) % elliptic_curve["n"]

    x, _ = point_add(scalar_multiply(u1, elliptic_curve["g"]),
                     scalar_multiply(u2, public_key))

    if (r % elliptic_curve["n"]) == (x % elliptic_curve["n"]):
        return 'Верификация пройдена'
    else:
        return 'Ошибка верификации!!'


# Задания №1 и №2
# Данные были взяты из примера
get_all_elements()

print(elliptic_curve)
print()

# Задание №3

# Генерация ключей первой стороной
first_private_key, first_public_key = make_key_pair()
print("Первая сторона")
print("Приватный ключ:", first_private_key)
print("Публичный ключ: ({0}, {1})".format(*first_public_key))
print()

# Генерация ключей второй стороной
second_private_key, second_public_key = make_key_pair()
print("Вторая сторона")
print("Приватный ключ:", second_private_key)
print("Публичный ключ: ({0}, {1})".format(*second_public_key))

# Обмен ключами и высчитывание общего секретного ключа
s1 = scalar_multiply(first_private_key, second_public_key)
s2 = scalar_multiply(second_private_key, first_public_key)
assert s1 == s2

print()
print('Общий секретный ключ: ({0}, {1})'.format(*s1))
print()

# Задание №4

# Генерируем ключи
private, public = make_key_pair()
print("Приватный ключ:", private)
print("Публичный ключ: ({0}, {1})".format(*public))

# Сообщение и подпись
msg = b'Hello world!'
signature = sign_message(private, msg)

print()
print('Сообщение:', msg)
print('Цифровая подпись: ({0}, {1})'.format(*signature))
print('Результат верификации:', verify_signature(public, msg, signature))

# Проверим другие сообщения
msg = b'Hello my dear friend!'
print()
print('Сообщение:', msg)
print('Результат верификации:', verify_signature(public, msg, signature))

# И другую пару ключей
private, public = make_key_pair()

msg = b'Hello world!'
print()
print('Сообщение:', msg)
print("Публичный ключ: (0x{:x}, 0x{:x})".format(*public))
print('Результат верификации:', verify_signature(public, msg, signature))
﻿using System;
using CSDS.Core.Exceptions;
using CSDS.Core.Repositories;
using CSDS.Infrastructure.Options;
using CSDS.Infrastructure.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace CSDS.Infrastructure
{
    public sealed class UnitOfWork : IUnitOfWork
    {
        private readonly DbContextOptions<CMSysContext> _options;
        private CMSysContext _context;
        private ITextRepository _textRepository; 
        private IUserRepository _userRepository;

        private bool _isDisposed;
        

        public UnitOfWork(IOptions<UnitOfWorkOptions> optionsAccessor) : this(optionsAccessor.Value)
        {
        }

        public UnitOfWork(UnitOfWorkOptions options)
        {
            var optionsBuilder = new DbContextOptionsBuilder<CMSysContext>();
            optionsBuilder.UseSqlServer(options.ConnectionString);
            _options = optionsBuilder.Options;
        }

        public UnitOfWork()
        {
        }

        private CMSysContext Context => _context ??= new CMSysContext(_options);

        public IUserRepository UserRepository => _userRepository ??= new UserRepository(Context);
        public ITextRepository TextRepository => _textRepository ??= new TextRepository(Context);

        public void Commit()
        {
            if (_context == null) return;

            if (_isDisposed) throw new ObjectDisposedException("UnitOfWork");

            try
            {
                Context.SaveChanges();
            }
            catch (DbUpdateException ex)
            {
                throw new RepositoryException("Update error", ex);
            }
            catch (Exception ex)
            {
                throw new RepositoryException("Commit error", ex);
            }
        }

        public void Dispose()
        {
            if (_context == null) return;

            if (!_isDisposed) Context.Dispose();

            _isDisposed = true;
        }
    }
}

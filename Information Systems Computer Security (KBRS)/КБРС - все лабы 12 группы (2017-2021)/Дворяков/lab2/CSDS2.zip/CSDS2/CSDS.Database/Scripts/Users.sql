﻿INSERT INTO [dbo].[User] ([Id], [Email], [Password], [FirstName], [LastName])
VALUES
	('29bf5270-c85b-480c-b007-656d60e4779c',  N'mdvoryakov@gmail.com',  N'12345678', N'Maksim',  N'Dvoryakov'),
	('18f63087-80fa-45ba-b623-1da170c90071',  N'denisSeldtsom@gmail.com',  N'qwertyui', N'Denis',  N'Seledtsov');
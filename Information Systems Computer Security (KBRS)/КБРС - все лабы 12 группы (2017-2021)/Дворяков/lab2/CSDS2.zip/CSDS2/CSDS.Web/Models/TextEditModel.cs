﻿using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace CSDS.Web.Models
{
    public class TextEditModel
    {
        [HiddenInput] public Guid Id { get; set; }

        [Required(ErrorMessage = "Name is required")]
        [StringLength(1024, ErrorMessage = "Max length is 1024")]
        public string Name { get; set; }

        public string Content { get; set; }
    }
}

﻿using CSDS.Utils;
using Microsoft.EntityFrameworkCore;
using CSDS.Core.Entities;

namespace CSDS.Infrastructure.Repositories
{
    internal abstract class Repository<TEntity> where TEntity : Entity
    {
        protected readonly CMSysContext Context;
        protected readonly DbSet<TEntity> DbSet;

        protected Repository(CMSysContext context)
        {
            Context = context;
            DbSet = Context.Set<TEntity>();
        }

        public void Add(TEntity entity)
        {
            Check.NotNull(entity, typeof(TEntity).ToString());
            DbSet.Add(entity);
        }

        public void Remove(TEntity entity)
        {
            Check.NotNull(entity, typeof(TEntity).ToString());
            DbSet.Remove(entity);
        }
    }
}

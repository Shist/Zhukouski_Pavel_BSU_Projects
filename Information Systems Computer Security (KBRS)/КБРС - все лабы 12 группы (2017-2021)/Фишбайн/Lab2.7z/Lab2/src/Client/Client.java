package Client;

import Exceptions.InvalidIPException;
import Exceptions.InvalidNicknameException;

import javax.xml.bind.SchemaOutputResolver;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.security.*;

/**
 * Обеспечивает работу программы в режиме клиента
 *
 * @author
 */
public class Client {
    private BufferedReader in;
    private PrintWriter out;
    private Socket socket;
    String publicKey1 = "821602471319565737360415032667946696834416249386371062219420802511563785020661176137919817840301322354";
    final int Port = 8000;
    /**
     * Запрашивает у пользователя ник и организовывает обмен сообщениями с
     * сервером
     */

    public String IDEA(String text, int k) {
        String str = "";
        for(int i = 0; i< text.length();i++) {
            char ch = text.charAt(i);
            ch = (char) (text.charAt(i)-k);
            str+=ch;

        }
        return str;
    }

    public Client() {
        Scanner scan = new Scanner(System.in);

        System.out.println("Enter server IP");
        System.out.println("Format: xxx.xxx.xxx.xxx");

        String ip = scan.nextLine();
        boolean is_correct = false;
        do{
            try{
                checkIP(ip);
                is_correct = true;
            }
            catch (InvalidIPException e){
                System.err.println(e.getMessage());
                System.out.println("Try again");
                ip = scan.nextLine();

            }
        } while(!is_correct);

        System.out.println("Enter your nickname:");

        String nickname = scan.nextLine();
        is_correct = false;
        do{
            try{
                checkNickname(nickname);
                is_correct = true;
            }
            catch (InvalidNicknameException e){
                System.err.println(e.getMessage());
                System.out.println("Try again");
                nickname = scan.nextLine();

            }
        } while(!is_correct);



        try {
            socket = new Socket(ip, Port);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);
            out.println(nickname);
            KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
            keyPairGenerator.initialize(512);
            KeyPair keyPair = keyPairGenerator.generateKeyPair();
            PublicKey publicKey = keyPair.getPublic();
            PrivateKey privateKey = keyPair.getPrivate();

            Resender resend = new Resender();
            resend.start();
            String str = "";
            out.println(publicKey1+"...");
            System.out.println("Enter your text title");
            str = scan.nextLine();
            out.println(str);
            resend.setStop();
            String criptKey = in.readLine();
            String criptText = in.readLine();
            System.out.println("Cripted text "+criptText);
            String text = IDEA(criptText,5);
            System.out.println("Normal text " + text);
            System.out.println(in.readLine());
            out.println("Advertising!");
            resend.setStop();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close();
        }
    }
    /**
     * Проверяет, является ли введённый пользователем адрес валидным
     *
     * @param ip
     *            IP адрес для проверки
     * @throws InvalidIPException
     *            введённый IP не является корректным
     */
    private void checkIP(String ip) throws InvalidIPException{
        String pattern = "((25[0-5]|2[0-4]\\d|[01]?\\d\\d?)\\.){3}(25[0-5]|2[0-4]\\d|[01]?\\d\\d?)";
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(ip);
        if (m.matches() || ip.compareTo("localhost") == 0){
            return;
        }
        throw new InvalidIPException();
    }

    /**
     * Проверяет, является ли введённый пользователем никнейм валидным
     *
     * @param nickname
     *            никнейм для проверки
     * @throws InvalidNicknameException
     *            введённый никнейм не является корректным
     */

    private void checkNickname(String nickname) throws InvalidNicknameException{
        String pattern = "^[a-zA-Z][a-zA-Z0-9-_\\.]{1,20}$";
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(nickname);
        if (m.matches()){
            return;
        }
        throw new InvalidNicknameException();
    }

    /**
     * Закрывает входной и выходной потоки и сокет
     */
    private void close() {
        try {
            in.close();
            out.close();
            socket.close();
        } catch (Exception e) {
            System.err.println("Threads were not closed!");
        }
    }

    /**
     * Класс в отдельной нити пересылает все сообщения от сервера в консоль.
     * Работает пока не будет вызван метод setStop().
     */
    private class Resender extends Thread {

        private boolean stoped;

        /**
         * Прекращает пересылку сообщений
         */
        public void setStop() {
            stoped = true;
        }

        /**
         * Считывает все сообщения от сервера и печатает их в консоль.
         * Останавливается вызовом метода setStop()
         */
        @Override
        public void run() {
            try {
                while (!stoped) {
                    String str = in.readLine();
                    System.out.println(str);
                }
            } catch (IOException e) {
                System.err.println("Error receiving message.");
                e.printStackTrace();
            }
        }
    }
}


import Foundation

struct FileModel {
    
    let name: String
    let text: String?
    
    init(name: String, text: String? = nil) {
        self.name = name
        self.text = text
    }
}

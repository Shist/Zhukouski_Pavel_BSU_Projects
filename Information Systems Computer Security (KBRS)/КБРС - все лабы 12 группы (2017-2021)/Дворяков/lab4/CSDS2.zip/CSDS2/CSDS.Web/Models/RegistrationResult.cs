﻿namespace CSDS.Web.Models
{
    public class RegistrationResult
    {
        public int N { get; set; }
    }
}

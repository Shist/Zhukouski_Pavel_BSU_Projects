package config

object ServerConfig {

  var fileDirectoryPath: String = "./files"
  var sessionKeyLifeTimeMills: Long = 300000

}
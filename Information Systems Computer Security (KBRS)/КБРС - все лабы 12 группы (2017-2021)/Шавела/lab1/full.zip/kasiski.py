import re
from math import ceil

from utils import is_all_letters, list_gcd

DIFF_THRESHOLD = 0.1

class Kasiski:
    def __init__(self, length):
        self.length = length

    def get_gramms(self, string):
        gramms = {}
        for i in range(len(string) - self.length):
            substr = string[i:i + self.length]
            if not is_all_letters(substr):
                continue
            if gramms.get(substr):
                continue
            matches = [m.start() for m in re.finditer('(?={})'.format(substr), string)]
            if len(matches) > 1:
                gramms[substr] = matches
        return gramms

    def get_differencies(self, array):
        diffs = {}
        for el in array:
            for i in range(len(el) - 1):
                key = el[i + 1] - el[i]
                diffs[key] = diffs.get(key, 0) + 1
        common_diff = diffs[max(diffs, key=lambda k: diffs[k])]
        min_accepted_diff = ceil(common_diff * DIFF_THRESHOLD)
        return [key for key in diffs if diffs[key] > min_accepted_diff]

    def get_key_len(self, encrypted):
        gramms = self.get_gramms(encrypted.lower())
        diffs = self.get_differencies(list(gramms.values()))
        gcd = list_gcd(diffs)
        return gcd
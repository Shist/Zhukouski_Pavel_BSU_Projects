import re
import utils
from math import ceil

from utils import is_all_letters, list_gcd, freq_to_sorted_list, add_to_char, alphabet, frequencies 

DIFF_THRESHOLD = 0.1

class Kasiski:
    def __init__(self, length):
        self.length = length
        
    def get_gramms(self, string):
        gramms = {}
        for i in range(len(string) - self.length):
            substr = string[i:i + self.length]
            if not is_all_letters(substr):
                continue
            if gramms.get(substr):
                continue
            matches = [m.start() for m in re.finditer('(?={})'.format(substr), string)]
            if len(matches) > 1:
                gramms[substr] = matches
        return gramms

    def get_differencies(self, array):
        diffs = {}
        for el in array:
            for i in range(len(el) - 1):
                key = el[i + 1] - el[i]
                diffs[key] = diffs.get(key, 0) + 1
        common_diff = diffs[max(diffs, key=lambda k: diffs[k])]
        min_accepted_diff = ceil(common_diff * DIFF_THRESHOLD)
        return [key for key in diffs if diffs[key] > min_accepted_diff]

    def get_len(self, encrypted):
        gramms = self.get_gramms(encrypted.lower())
        diffs = self.get_differencies(list(gramms.values()))
        gcd = list_gcd(diffs)
        return gcd


class Analyzer:
    def __init__(self, length):
        self.length = length

    @staticmethod
    def count_frequencies(string, alphabet):
        letters_count = dict.fromkeys(alphabet, 0)
        escaped = 0
        for c in string:
            if letters_count.get(c.lower()) is not None:
                letters_count[c.lower()] += 1
            else:
                escaped += 1
        string_len = len(string) - escaped
        return {letter: count / string_len for letter, count in letters_count.items()}

    def next_freq_closer(self, value, known_freq):
        return abs(value - known_freq[0]['freq']) > abs(value - known_freq[1]['freq'])

    def count_shift(self, a, b):
        return ord(a['letter']) - ord(b['letter'])

    def find_keyword_letter(self, string):
        shifts = {}
        known_freq = utils.known_freq[:].copy()
        freq = freq_to_sorted_list(Analyzer.count_frequencies(string, utils.alphabet))
        for el in freq:
            i = 0
            while i < len(known_freq) - 1:
                closest = known_freq[i]
                if not self.next_freq_closer(el['freq'], known_freq[i:]):
                    break
                i += 1
            shift = self.count_shift(el, closest)
            shifts[shift] = shifts.get(shift, 0) + 1
        common_shift = max(shifts, key=lambda k: shifts[k])
        return add_to_char(utils.alphabet[0], common_shift, utils.alphabet)

    def find_keyword(self, string):
        parts = [string[i::self.length] for i in range(self.length)]
        letters = list(map(self.find_keyword_letter, parts))
        return ''.join(letters)
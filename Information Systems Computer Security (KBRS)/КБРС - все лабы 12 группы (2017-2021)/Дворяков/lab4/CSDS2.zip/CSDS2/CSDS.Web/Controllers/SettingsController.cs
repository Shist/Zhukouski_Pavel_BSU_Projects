﻿using System;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;
using CSDS.Core.Repositories;
using CSDS.Web.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;

namespace CSDS.Web.Controllers
{
    public class SettingsController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public SettingsController(IUnitOfWork unitOfWork) => _unitOfWork = unitOfWork;

        [HttpGet("[controller]/[action]")]
        public IActionResult Settings()
        {
            using var RSA = new RSACryptoServiceProvider();
            var rsa = RSA.ExportParameters(true);

            return View(new SettingsViewModel
            {
                Q = Convert.ToBase64String(rsa.Q),
                P = Convert.ToBase64String(rsa.P),
                Exponent = Convert.ToBase64String(rsa.Exponent),
                Modulus = Convert.ToBase64String(rsa.Modulus),
                DQ = Convert.ToBase64String(rsa.DQ),
                DP = Convert.ToBase64String(rsa.DP),
                D = Convert.ToBase64String(rsa.D),
                InverseQ = Convert.ToBase64String(rsa.InverseQ)
            });
        }

        [HttpPost("[controller]/[action]")]
        public IActionResult Settings(SettingsViewModel model)
        {
            if(string.IsNullOrEmpty(model.Q))
                return View(model);

            var principal = HttpContext.User;
            var identity = HttpContext.User.Identity as ClaimsIdentity;
            var claimUser = principal.Claims.FirstOrDefault(x => x.Type == "userId");

            if (claimUser == null) return NotFound();

            var user = _unitOfWork.UserRepository.Find(Guid.Parse(claimUser.Value), track: true);

            user.SecretKey = JsonSerializer.Serialize(model);

            _unitOfWork.Commit();

            if (identity != null)
            {
                identity.RemoveClaim(claimUser);
                identity.AddClaim(new Claim(ClaimTypes.Role, "Full"));
            }

            HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal,
                new AuthenticationProperties { AllowRefresh = true });

            return RedirectToAction("List", "Text");
        }
    }
}

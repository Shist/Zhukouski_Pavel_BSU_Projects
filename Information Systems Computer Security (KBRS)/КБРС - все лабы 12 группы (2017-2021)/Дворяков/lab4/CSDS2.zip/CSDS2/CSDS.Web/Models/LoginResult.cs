﻿namespace CSDS.Web.Models
{
    public enum LoginResult
    {
        Success,
        IncorrectPassword
    }
}

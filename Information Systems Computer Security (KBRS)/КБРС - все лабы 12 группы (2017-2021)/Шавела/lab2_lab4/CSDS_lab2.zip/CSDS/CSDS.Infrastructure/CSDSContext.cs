﻿using CSDS.Infrastructure.Configurations;
using Microsoft.EntityFrameworkCore;

namespace CSDS.Infrastructure
{
    internal class CMSysContext : DbContext
    {
        public CMSysContext(DbContextOptions<CMSysContext> options) : base(options)
        {
        }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.ApplyConfiguration(new UserConfiguration());
            builder.ApplyConfiguration(new TextConfiguration());
        }
    }
}

//
//  FileDetailsViewController.swift


import UIKit

class FileDetailsViewController: UIViewController {

    
    // MARK: - IBOutlets
    @IBOutlet weak var textView: UITextView!
    
    
    // MARK: - properties
    var file: FileModel?
    
    class func newInstance(withFile file: FileModel) -> FileDetailsViewController {
        let vc = FileDetailsViewController(nibName: "FileDetailsViewController",
                                           bundle: nil)
        vc.file = file
        return vc
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = file?.name
        textView.isEditable = false
        textView.text = file?.text
    }


}

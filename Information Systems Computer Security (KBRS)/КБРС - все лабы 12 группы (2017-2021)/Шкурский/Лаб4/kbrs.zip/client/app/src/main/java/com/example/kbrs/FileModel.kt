package com.example.kbrs

data class FileModel(
    val nameOfFile: String
)
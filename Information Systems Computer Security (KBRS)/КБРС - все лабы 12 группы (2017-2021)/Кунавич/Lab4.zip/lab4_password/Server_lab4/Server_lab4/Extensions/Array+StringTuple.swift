
import Foundation

extension Array where Array.Element == (String, String) {
    
    func getValueForKey(_ key: String) -> String? {
        first(where: {$0.0 == key})?.1
    }
    
}

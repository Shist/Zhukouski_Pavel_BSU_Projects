﻿INSERT INTO [dbo].[User] ([Id], [Email], [Password], [FirstName], [LastName])
VALUES
	('18f63087-80fa-45ba-b623-1da170c90072',  N'shavela99@gmail.com',  N'qwerty99', N'Vera',  N'Shavela');
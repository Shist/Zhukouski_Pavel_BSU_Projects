﻿using CSDS.Infrastructure;
using System;
using CSDS.Infrastructure.Options;

namespace CSDS.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            UnitOfWork work = new UnitOfWork(new UnitOfWorkOptions { ConnectionString = "Data Source=(local);Initial Catalog=CSDS;Integrated Security=True; MultipleActiveResultSets=true" });
            foreach (var i in work.UserRepository.List())
            {
                Console.WriteLine(i.Email);
            }
        }
    }
}

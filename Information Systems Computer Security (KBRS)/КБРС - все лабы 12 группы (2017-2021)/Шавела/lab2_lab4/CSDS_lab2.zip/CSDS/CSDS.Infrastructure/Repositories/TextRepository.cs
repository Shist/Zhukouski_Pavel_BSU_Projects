﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using CSDS.Core.Entities;
using CSDS.Core.Repositories;
using Microsoft.EntityFrameworkCore;

namespace CSDS.Infrastructure.Repositories
{
    class TextRepository : Repository<Text>, ITextRepository
    {
        public TextRepository(CMSysContext context) : base(context)
        {
        }

        public Text Find(Guid id, string includeProperties = "", bool track = true)
        {
            var query = track ? DbSet.AsQueryable() : DbSet.AsQueryable().AsNoTracking();

            foreach (var includeProperty in includeProperties.Split
                (new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                query = query.Include(includeProperty);

            return query.SingleOrDefault(x => x.Id == id);
        }

        public IEnumerable<Text> List(Expression<Func<Text, bool>> predicate = null,
            Func<IQueryable<Text>, IOrderedQueryable<Text>> orderBy = null,
            string includeProperties = "", bool track = true)
        {
            var query = track ? DbSet.AsQueryable() : DbSet.AsQueryable().AsNoTracking();

            if (predicate != null) query = query.Where(predicate);

            foreach (var includeProperty in includeProperties.Split
                (new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                query = query.Include(includeProperty);

            return orderBy != null ? orderBy(query).ToList() : query.ToList();
        }

        public (IEnumerable<Text>, int) PagingList(int offset, int pageSize,
            List<Expression<Func<Text, bool>>> predicateList = null,
            Func<IQueryable<Text>, IOrderedQueryable<Text>> orderBy = null,
            string includeProperties = "", bool track = true)
        {
            var query = track ? DbSet.AsQueryable() : DbSet.AsQueryable().AsNoTracking();

            foreach (var predicate in predicateList)
            {
                if (predicate != null) query = query.Where(predicate);
            }

            foreach (var includeProperty in includeProperties.Split
                (new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                query = query.Include(includeProperty);

            if (orderBy != null) query = orderBy(query);

            var count = query.Count();
            var items = query.Skip((offset - 1) * pageSize).Take(pageSize).ToList();

            return (items, count);
        }
    }
}

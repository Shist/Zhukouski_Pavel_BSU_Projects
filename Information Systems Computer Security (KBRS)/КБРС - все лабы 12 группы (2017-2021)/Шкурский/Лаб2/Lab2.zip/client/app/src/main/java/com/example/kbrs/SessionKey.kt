package com.example.kbrs

import com.google.gson.annotations.SerializedName

data class SessionKey (
    @SerializedName("sessionKey") val sessionKey : String
)
﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CSDS.Web.Controllers
{
    public class RulesController : Controller
    {
        [HttpGet("[controller]/[action]")]
        public IActionResult Index()
        {
            return View();
        }
    }
}

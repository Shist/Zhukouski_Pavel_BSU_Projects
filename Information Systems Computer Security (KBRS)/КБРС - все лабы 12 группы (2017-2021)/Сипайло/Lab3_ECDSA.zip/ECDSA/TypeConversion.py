def stringToBigInt(s):
    '''
    maps a string to an integer
    '''
    return int(str(s).encode('utf-8').hex(), 16)
    
def bigIntToString(i):
    '''
    maps an integer to a string
    '''
    s=hex(i)
    return str(s[2:-1]).encode('utf-8').hex()

alphabet = '123456789abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ'
base_count = len(alphabet)
def intTob58(i):
    '''
    maps an integer to a base-58 string
    '''
    encode = ''  	
    if (i < 0):
        return ''
    while (i >= base_count):	
        mod = i % base_count
        encode = alphabet[int(mod)] + encode
        i = i / base_count
    if (i):
        s58 = alphabet[int(i)] + encode
    return s58
	
def b58toInt(s58):
    '''
    maps a base-58 string to an integer
    '''
    i = 0
    multi = 1
    s58 = s58[::-1]
    for char in s58:
        i += multi * alphabet.index(char)
        multi = multi * base_count	
    return i
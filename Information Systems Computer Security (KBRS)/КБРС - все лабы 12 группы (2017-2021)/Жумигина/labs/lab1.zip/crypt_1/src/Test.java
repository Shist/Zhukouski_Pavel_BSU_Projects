import java.io.FileNotFoundException;
import java.util.Random;

public class Test {
    private double similarity(String a, String b) { // % одинаковых символов
        int n = a.length();
        int similar = 0;
        for (int i = 0; i < n; i++) {
            similar += (a.charAt(i) == b.charAt(i) ? 1 : 0);
        }
        return (double)similar / n;
    }

    public void testTextLengthByKasiskaTask3(String bigText, String key, int n, double eps, int keywordLength) {
        StringBuilder str1 = new StringBuilder();
        String keyword = key.toUpperCase();
        Kasiski kasiska = new Kasiski();
        Vigner vigener = new Vigner();
        Reader readWriteFiles = new Reader();
        int[] textLengths = {500, 1000, 1500, 2000};

        for (int textLength: textLengths) {
            double successLength = 0, successKeywordEps = 0, successKeywordWhole = 0;
            for (int i = 1; i <= n; i++) {
                String text = bigText.substring(0, textLength);
                String encoded = null;
                try {
                    encoded = vigener.encrypt(text, keyword);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                int keywordGuessedLength = kasiska.kasiski(encoded, 3); //keyword guessed length

                if (keywordGuessedLength == keywordLength) {
                    successLength++;
                    String guessKeyword = kasiska.vigenerGuessKey(encoded, keywordGuessedLength);

                    double p = similarity(keyword, guessKeyword);
                    if (p >= eps) {
                        successKeywordEps++;
                    }
                    if (p == 1.0) {
                        successKeywordWhole++;
                    }
                }
            }
            str1.append("textLength = ").append(textLength).append(" successLength = ").append(successLength / n).append(" successKeywordEps = ").append(successKeywordEps / n).append(" successKeywordWhole = ").append(successKeywordWhole / n).append("\n");
        }
        System.out.println("Task 3: " + str1.toString());
        readWriteFiles.writeFile("AttackAnalysisTextLengthTests.txt", str1.toString());
    }


    // фиксированный textLength
    public void testKeywordLengthByKasiskaTask4(int n, double eps, int textLength) {
        StringBuilder str1 = new StringBuilder();
        Reader readWriteFiles = new Reader();
        Vigner vigener = new Vigner();
        Kasiski kasiska = new Kasiski();
        int[] keywordLengths = { 5, 10, 20, 50};
        String text = null;
        try {
            text = readWriteFiles.ReadFromFile("start.txt");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        String bigKeyword = "IPUTTHECHEESECAREFULLYINMYPOCKETASISLIPOUTSIDEOURPARTOF";
        for (int keywordLength: keywordLengths) {
            double successLength = 0, successKeywordEps = 0, successKeywordWhole = 0;
            for (int i = 1; i <= n; i++) {
                int keywordPosition = new Random().nextInt(bigKeyword.length() - keywordLength);

                String keyword = bigKeyword.substring(keywordPosition, keywordPosition + keywordLength);

                String encoded = null;
                try {
                    encoded = vigener.encrypt(text, keyword);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                int keywordGuessedLength = kasiska.kasiski(encoded, 3); //keyword guessed length

                if (keywordGuessedLength == keywordLength) {
                    successLength++;
                    String guessKey = kasiska.vigenerGuessKey(encoded, keywordGuessedLength);

                    double p = similarity(keyword, guessKey);
                    if (p >= eps) {
                        successKeywordEps++;
                    }
                    if (p == 1.0) {
                        successKeywordWhole++;
                    }

                }
                
            }
            str1.append("keywordLength = ").append(keywordLength).append(" successLength = ").append(successLength / n).append(" successKeywordEps = ").append(successKeywordEps / n).append(" successKeywordWhole = ").append(successKeywordWhole / n).append("\n");
        }
        System.out.println("Task 4: " + str1.toString());
        readWriteFiles.writeFile("AttackAnalysisKeyLengthTests.txt", str1.toString());
    }

}

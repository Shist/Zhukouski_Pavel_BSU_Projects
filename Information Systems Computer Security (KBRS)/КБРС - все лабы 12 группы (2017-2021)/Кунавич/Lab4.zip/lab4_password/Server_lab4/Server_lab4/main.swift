import Foundation

let server = Server()
server.start()


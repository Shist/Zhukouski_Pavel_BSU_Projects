package Exceptions;

public class InvalidIPException extends Exception {
    public InvalidIPException(){
        this("Check server IP address");
    }

    public InvalidIPException(String message){
        super(message);
    }
}

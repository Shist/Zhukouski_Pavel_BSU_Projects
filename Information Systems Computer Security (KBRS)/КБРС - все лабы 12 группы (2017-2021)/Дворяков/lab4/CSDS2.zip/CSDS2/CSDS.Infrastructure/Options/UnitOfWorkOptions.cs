﻿namespace CSDS.Infrastructure.Options
{
    public sealed class UnitOfWorkOptions
    {
        public string ConnectionString { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using CSDS.Core.Entities;
using CSDS.Core.Repositories;
using Microsoft.EntityFrameworkCore;


namespace CSDS.Infrastructure.Repositories
{
    internal sealed class UserRepository : Repository<User>, IUserRepository
    {
        public UserRepository(CMSysContext context) : base(context)
        {
        }

        public User Find(Guid id, string includeProperties = "", bool track = true)
        {
            var query = track ? DbSet.AsQueryable() : DbSet.AsQueryable().AsNoTracking();

            foreach (var includeProperty in includeProperties.Split
                (new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                query = query.Include(includeProperty);

            return query.SingleOrDefault(x => x.Id == id);
        }

        public IEnumerable<User> List(Expression<Func<User, bool>> predicate = null,
            Func<IQueryable<User>, IOrderedQueryable<User>> orderBy = null,
            string includeProperties = "", bool track = true)
        {
            var query = track ? DbSet.AsQueryable() : DbSet.AsQueryable().AsNoTracking();

            if (predicate != null) query = query.Where(predicate);

            foreach (var includeProperty in includeProperties.Split
                (new[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                query = query.Include(includeProperty);

            return orderBy != null ? orderBy(query).ToList() : query.ToList();
        }

        public User FindByEmail(string email)
        {
            email = email.ToUpper();
            return DbSet.SingleOrDefault(x => x.Email.ToUpper() == email);
        }
    }
}

#include <stdio.h>
#include <tchar.h>
#include <iostream>
#include <string>
#include <conio.h>
#include <array>
#include <vector>
#include <locale>
#include <fstream>
#include <streambuf>
#include <Windows.h>

using namespace std;

void CaesarIn(int k) {
	ifstream input("input.txt");
	ofstream output("caesarin.txt");

	char buff;
	int iter;

	if (!input.is_open())
		cout << "���� �� ����� ���� ������!\n";
	else {
		while (!input.eof()) {
			buff = (int)input.get();
			if (buff == ' ')
				output << ' ';
			else if (buff == '\n')
				output << '\n';
			else if (buff == ',') {
				output << ',';
			}
			else if (buff == '.') {
				output << '.';
			}
			else if (buff == '?') {
				output << '?';
			}
			else if (buff == EOF) {}
			else if (buff >= 'A' && buff <= 'Z') {
				buff += (k % 26);
				if (buff > 'Z')
					buff -= 26;
				output << buff;
			}
			else if (buff >= 'a' && buff <= 'z') {
				buff += (k % 26);
				if (buff > 'z')
					buff -= 26;
				output << buff;
			}
			else if (buff >= '�' && buff <= '�') {
				buff += (k % 33);
				if (buff > '�')
					buff -= 33;
				output << buff;
			}
			else if (buff >= '�' && buff <= '�') {
				buff += (k % 33);
				if (buff > '�')
					buff -= 33;
				output << buff;
			}
		}
	}
	input.close();
	output.close();
}

void CaesarOut(int k) {
	ifstream input("caesarin.txt");
	ofstream output("caesarout.txt");

	char buff;
	int iter;

	if (!input.is_open())
		cout << "���� �� ����� ���� ������!\n";
	else {
		while (!input.eof()) {
			buff = (int)input.get();
			if (buff == ' ')
				output << ' ';
			else if (buff == '\n')
				output << '\n';
			else if (buff == ',') {
				output << ',';
			}
			else if (buff == '.') {
				output << '.';
			}
			else if (buff == '?') {
				output << '?';
			}
			else if (buff == EOF) {}
			else if (buff >= 'A' && buff <= 'Z') {
				buff -= (k % 26);
				if (buff < 'A')
					buff += 26;
				output << buff;
			}
			else if (buff >= 'a' && buff <= 'z') {
				buff -= (k % 26);
				if (buff < 'a')
					buff += 26;
				output << buff;
			}
			else if (buff >= '�' && buff <= '�') {
				buff -= (k % 33);
				if (buff > '�')
					buff += 33;
				output << buff;
			}
			else if (buff >= '�' && buff <= '�') {
				buff -= (k % 33);
				if (buff > '�')
					buff += 33;
				output << buff;
			}
		}
	}
	input.close();
	output.close();
}

void MonoAlphabetIn(int k)
{
	ifstream input("input.txt");
	ofstream output("monoalp.txt");

	char buff;
	int iter;

	if (!input.is_open())
		cout << "���� �� ����� ���� ������!\n";
	else {
		while (!input.eof()) {
			buff = input.get();
			if (buff == ' ')
				output << ' ';
			else if (buff == '\n')
				output << '\n';
			else if (buff == ',') {
				output << ',';
			}
			else if (buff == '.') {
				output << '.';
			}
			else if (buff == '?') {
				output << '?';
			}
			else if (buff == EOF) {}
			else if (buff >= 'A' && buff <= 'Z') {
				iter = int(buff) - int('A');
				iter = (iter + k) % 26;
				iter += (int)'A';
				output << char(iter);
			}
			else if (buff >= 'a' && buff <= 'z') {
				iter = int(buff) - int('a');
				iter = (iter + k) % 26;
				iter += (int)'a';
				output << char(iter);
			}
			else if (buff >= '�' && buff <= '�') {
				iter = int(buff) - int('�');
				iter = (iter + k) % 32;
				iter += (int)'�';
				output << char(iter);
			}
			else if (buff >= '�' && buff <= '�') {
				iter = int(buff) - int('�');
				iter = (iter + k) % 32;
				iter += (int)'�';
				output << char(iter);
			}
		}
	}
	input.close();
	output.close();
}

void MonoAlphabetOut(int k)
{
	ifstream input("monoalp.txt");
	ofstream output("monoalpout.txt");

	char buff;
	int iter;

	if (!input.is_open())
		cout << "���� �� ����� ���� ������!\n";
	else {
		while (!input.eof()) {
			buff = input.get();
			if (buff == ' ')
				output << ' ';
			else if (buff == '\n')
				output << '\n';
			else if (buff == ',') {
				output << ',';
			}
			else if (buff == '.') {
				output << '.';
			}
			else if (buff == '?') {
				output << '?';
			}
			else if (buff == EOF) {}
			else if (buff >= 'A' && buff <= 'Z') {
				iter = int(buff) - int('A');
				iter = (iter - k + 26) % 26;
				iter += (int)'A';
				output << char(iter);
			}
			else if (buff >= 'a' && buff <= 'z') {
				iter = int(buff) - int('a');
				iter = (iter - k + 26) % 26;
				iter += (int)'a';
				output << char(iter);
			}
			else if (buff >= '�' && buff <= '�') {
				iter = int(buff) - int('�');
				iter = (iter - k + 32) % 32;
				iter += (int)'�';
				output << char(iter);
			}
			else if (buff >= '�' && buff <= '�') {
				iter = int(buff) - int('�');
				iter = (iter - k + 32) % 32;
				iter += (int)'�';
				output << char(iter);
			}
		}
	}
	input.close();
	output.close();
}

int main()
{
	setlocale(LC_ALL, "Rus");
	SetConsoleCP(1251);
	SetConsoleOutputCP(1251);

	int k = 0;
	cout << "�����: ";
	cin >> k;

	if (k < 1)
		return 0;

	cout << "�������� ������. " << '\n';
	CaesarIn(k);
	cout << "���������� ������." << '\n';
	CaesarOut(k);

	cout << "�������� �����������. " << '\n';
	MonoAlphabetIn(k);
	cout << "���������� �����������." << '\n';
	MonoAlphabetOut(k);

	system("pause");
	return 0;
}
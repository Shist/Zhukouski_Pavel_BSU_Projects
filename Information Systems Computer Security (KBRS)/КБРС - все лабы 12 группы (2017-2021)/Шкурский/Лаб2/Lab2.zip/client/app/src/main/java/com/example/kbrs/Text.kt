package com.example.kbrs

import com.google.gson.annotations.SerializedName

data class Text (
    @SerializedName("text") val text : String
)
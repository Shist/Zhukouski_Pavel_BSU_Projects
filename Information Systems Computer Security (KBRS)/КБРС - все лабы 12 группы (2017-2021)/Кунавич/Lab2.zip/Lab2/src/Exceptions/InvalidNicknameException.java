package Exceptions;

public class InvalidNicknameException extends Exception {
    public InvalidNicknameException(){
        this("Nickname must be with a limitation of 2-20 characters, which can be " +
                "letters and numbers, the first character is necessarily a letter");
    }

    public InvalidNicknameException(String message){
        super(message);
    }
}

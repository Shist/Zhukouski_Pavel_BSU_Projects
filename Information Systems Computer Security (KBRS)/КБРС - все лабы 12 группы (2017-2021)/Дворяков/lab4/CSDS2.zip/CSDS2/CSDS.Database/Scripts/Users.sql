﻿INSERT INTO [dbo].[User] ([Id], [Email], [Password], [FirstName], [LastName])
VALUES
	('18f63087-80fa-45ba-b623-1da170c90071',  N'denisSeldtsom@gmail.com',  N'qwertyui', N'Denis',  N'Seledtsov');
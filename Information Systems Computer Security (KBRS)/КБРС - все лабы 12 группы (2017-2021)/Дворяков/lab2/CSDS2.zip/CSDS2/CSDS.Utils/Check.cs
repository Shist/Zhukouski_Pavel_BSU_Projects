﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CSDS.Utils
{
    public static class Check
    {
        public static void NotNull<T>(T entity, string paramName)
        {
            if (entity == null) throw new ArgumentNullException(paramName);
        }
    }
}

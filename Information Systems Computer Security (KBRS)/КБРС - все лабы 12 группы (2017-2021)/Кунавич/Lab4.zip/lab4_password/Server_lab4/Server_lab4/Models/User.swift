
import Foundation

struct User: Hashable {
    
    let login: String
    let mail: String
    let password: String
    
}

struct UserAuthInfo {

    let key: String
    let encodedKey: [UInt8]
    
}

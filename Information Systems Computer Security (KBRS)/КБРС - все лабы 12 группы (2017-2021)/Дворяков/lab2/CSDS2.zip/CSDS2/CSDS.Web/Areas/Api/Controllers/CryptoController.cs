﻿using System;
using System.ComponentModel;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using CSDS.ApplicationServices.Interfaces;
using CSDS.Core.Repositories;
using CSDS.Web.Areas.Api.Models;
using CSDS.Web.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CSDS.Web.Areas.Api.Controllers
{
    [ApiController]
    public class CryptoController : ControllerBase
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ICryptoService _cryptoService;

        public CryptoController(IUnitOfWork unitOfWork, ICryptoService cryptoService)
        {
            _unitOfWork = unitOfWork;
            _cryptoService = cryptoService;
        }

        [HttpGet("[controller]")]
        public ActionResult<CryptoModel> Get()
        {
            var principal = HttpContext.User;
            var claimUser = principal.Claims.FirstOrDefault(x => x.Type == "userId");
            var claimKey = principal.Claims.FirstOrDefault(x => x.Type == "key");

            if (claimKey == null || claimUser == null) return BadRequest();

            var user = _unitOfWork.UserRepository.Find(Guid.Parse(claimUser.Value));

            using var RSA = new RSACryptoServiceProvider();
            var rsa = RSA.ExportParameters(true);
            var key = JsonSerializer.Deserialize<SettingsViewModel>(user.SecretKey);
            key.K = claimKey.Value;
            rsa.Q = Convert.FromBase64String(key.Q);
            rsa.D = Convert.FromBase64String(key.D);
            rsa.DP = Convert.FromBase64String(key.DP);
            rsa.DQ = Convert.FromBase64String(key.DQ);
            rsa.Exponent = Convert.FromBase64String(key.Exponent);
            rsa.InverseQ = Convert.FromBase64String(key.InverseQ);
            rsa.Modulus = Convert.FromBase64String(key.Modulus);
            rsa.P = Convert.FromBase64String(key.P);
            var encryptedData = _cryptoService.RSAEncrypt(Encoding.Unicode.GetBytes(claimKey.Value),
                rsa, false);

            var a = Utils.Encoder.ByteArrayToString(encryptedData);

            return Ok(new CryptoModel
            {
                SessionKey = Utils.Encoder.ByteArrayToString(encryptedData),
                PrivateKey = key
            });
        }
    }
}

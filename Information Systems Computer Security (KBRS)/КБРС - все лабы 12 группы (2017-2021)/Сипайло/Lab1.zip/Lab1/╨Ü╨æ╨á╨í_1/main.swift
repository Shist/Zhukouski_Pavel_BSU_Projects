//
//  main.swift
//  КБРС_1
//
//  Created by Anton Sipaylo on 9/24/20.
//

import Foundation

enum Alphabet {
    case russian
    case english
    
    func firstCharacterValue(for character: Character) -> UInt8 {
        switch self {
        case .russian: return character.isUppercase ? Character("А").asciiValue ?? 0 : Character("а").asciiValue ?? 0
        case .english: return character.isUppercase ? Character("A").asciiValue ?? 0 : Character("a").asciiValue ?? 0
        }
    }
    
    func finishCharacterValue(for character: Character) -> UInt8 {
        switch self {
        case .russian: return character.isUppercase ? Character("Я").asciiValue ?? 0 : Character("я").asciiValue ?? 0
        case .english: return character.isUppercase ? Character("Z").asciiValue ?? 0 : Character("z").asciiValue ?? 0
        }
    }
}

extension Character {
    func move(with character: Character) -> Character {
        guard let asciiValue = asciiValue else { return self }
        let alphabet = characterAlphabet()
        guard asciiValue >= alphabet.firstCharacterValue(for: self),
              asciiValue <= alphabet.finishCharacterValue(for: self) else { return self }
        let characterAsciiValue = character.asciiValue ?? 0
        let newCharacterAsciiValue = asciiValue + characterAsciiValue - alphabet.firstCharacterValue(for: character)
        let remain = newCharacterAsciiValue % alphabet.finishCharacterValue(for: self)
        return remain > 0 && newCharacterAsciiValue > alphabet.finishCharacterValue(for: self) ?
            Character(UnicodeScalar(alphabet.firstCharacterValue(for: self) + remain - 1)) :
            Character(UnicodeScalar(newCharacterAsciiValue))
    }
    
    private func characterAlphabet() -> Alphabet {
        return asciiValue ?? 0 >= Alphabet.russian.firstCharacterValue(for: self) &&
            asciiValue ?? 0 <= Alphabet.russian.finishCharacterValue(for: self) ?
            .russian : .english
    }
}

extension String {
    subscript(_ distance: Int) -> Character {
        return self[index(startIndex, offsetBy: distance)]
    }
    
    subscript(_ range: Range<Int>) -> String {
        return String(self[index(startIndex, offsetBy: range.startIndex)...index(startIndex, offsetBy: range.endIndex)])
    }
}

extension Array {
    subscript(safe index: Int) -> Element? {
        guard index < count else { return nil }
        return self[index]
    }
}

public final class Euclid {
    func maximumCommonDivisor(of firstNumber: Int, and secondNumber: Int) -> Int {
        var (maximum, minimum): (Int, Int) = {
            return firstNumber > secondNumber ? (firstNumber, secondNumber) : (secondNumber, firstNumber)
        }()
        while minimum != 0 {
            let min = maximum % minimum
            maximum = minimum
            minimum = min
        }
        return maximum
    }
}

public final class VigenereCipher {
    public init() { }
    
    func cipher(text: String, with key: String) -> String {
        return String(text.uppercased().enumerated().map { element in
            let (index, character) = element
            let keyCharacter = key[key.index(key.startIndex, offsetBy: index % key.count)]
            let cipherredCharacter = character.move(with: keyCharacter)
            print("\(character) + \(keyCharacter) = \(cipherredCharacter)")
            return cipherredCharacter
        })
    }
}

public final class KasiskiMethod {
    struct IterationInformation {
        let string: String
        var length = 0
        var firstIndex = 0
        var secondIndex = 0
    }
    
    private let minimalSequenceLength: Int
    
    init(minimalSequenceLength: Int) {
        self.minimalSequenceLength = minimalSequenceLength
    }
    
    func perform(with string: String) -> [IterationInformation] {
        var iterationData: [IterationInformation] = []
        for firstIndex in 0..<string.count {
            for secondIndex in (firstIndex + 1)..<string.count {
                let length: Int = {
                    for index in 0..<string.count - secondIndex {
                        if string[firstIndex + index] != string[secondIndex + index] {
                            return index
                        }
                    }
                    return string.count - secondIndex
                }()
                guard length > minimalSequenceLength else {
                    continue
                }
                var substring = string[firstIndex..<firstIndex + length]
                substring.removeAll { !$0.isASCII || !$0.isLetter }
                iterationData.append(
                    IterationInformation(
                        string: substring,
                        length: length,
                        firstIndex: firstIndex,
                        secondIndex: secondIndex)
                )
                print("Found repeated substing = \(substring): first = \(firstIndex), second = \(secondIndex), length = \(length)")
            }
        }
        return iterationData
    }
    
    func findKeyWordLength(with iterationData: [IterationInformation]) -> Int {
        let distances = iterationData.map { $0.secondIndex - $0.firstIndex }.sorted(by: <)
        var divisorsStatistics: [Int: Int] = [:]
        for firstIndex in 0..<distances.count {
            for secondIndex in firstIndex + 1..<distances.count {
                let maximumDivisor = Euclid().maximumCommonDivisor(of: distances[firstIndex],
                                                                   and: distances[secondIndex])
                divisorsStatistics[maximumDivisor] = (divisorsStatistics[maximumDivisor] ?? 0) + 1
            }
        }

        var bestDivisor = 0
        var bestDivisorRepeatings = 0
        for (divisor, repeatings) in divisorsStatistics {
            if repeatings > bestDivisorRepeatings, divisor != 1 {
                bestDivisorRepeatings = repeatings
                bestDivisor = divisor
            }
        }
        
        print("bestDivisor = \(bestDivisor), bestDivisorRepeatings = \(bestDivisorRepeatings)")
        return bestDivisor
    }
}

func printAlphabet() {
    print("Alphabet: ")
    let startSymbol = Character("A")
    let alphabetStart = startSymbol.asciiValue ?? 0
    let alphabetEnd = Character("Z").asciiValue ?? 0
    (alphabetStart...alphabetEnd).forEach {
        print("\(Character(UnicodeScalar($0))) -> \($0)", terminator: " ")
    }
    print()
}

printAlphabet()

let textToCipher = "Push notifications are one of the most important interaction points of your app with your users. Simply put, a push notification is a way to send any type of data to your user’s app, even if the user isn’t actively using it. The user will normally see the push notification appear as a banner alert on the device, a badge on the app icon and/or a sound. Push notifications are a direct line of communication to your user. You can alert the user of new content, new messages from friends or any other interesting piece of information. Notifications also provide users with a quick way to interact with your app and allow for faster interaction via background data downloads"
let key = "MOUSE"
let cipherredText = VigenereCipher().cipher(text: textToCipher, with: key)
let minimalSequenceLength = 1

print("cipherredText = \(cipherredText)")
let kasiskiMethod = KasiskiMethod(minimalSequenceLength: minimalSequenceLength)
let iterationData = kasiskiMethod.perform(with: cipherredText)
print(iterationData)
let keyWordLength = kasiskiMethod.findKeyWordLength(with: iterationData)
print(keyWordLength)
if keyWordLength == key.count {
    print("SUCCESS")
}
else {
    print("FAILURE")
}

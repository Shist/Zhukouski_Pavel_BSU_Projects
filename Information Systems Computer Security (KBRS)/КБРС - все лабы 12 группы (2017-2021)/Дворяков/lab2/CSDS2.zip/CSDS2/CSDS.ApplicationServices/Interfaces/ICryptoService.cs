﻿using System.Security.Cryptography;

namespace CSDS.ApplicationServices.Interfaces
{
    public interface ICryptoService
    {
        string EncryptStringToBytes_Aes(string plainText, string key);
        string DecryptStringFromBytes_Aes(string cipherText, string key);

        public byte[] RSAEncrypt(byte[] DataToEncrypt, RSAParameters RSAKeyInfo, bool DoOAEPPadding);

        public byte[] RSADecrypt(byte[] DataToDecrypt, RSAParameters RSAKeyInfo, bool DoOAEPPadding);
    }
}
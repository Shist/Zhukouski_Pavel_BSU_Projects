import utils

class Vigenere:
    def __init__(self, keyword):
        self.keyword = keyword
        self.shifts = [ord(c.lower()) - ord(utils.alphabet[0]) for c in keyword]

    def process_string(self, string, sign=1):
        shifts = self.shifts
        period = len(self.keyword)
        parts = [string[i::period] for i in range(period)]

        result_parts = [utils.process_string(parts[i], sign * shifts[i], utils.alphabet) for i in range(period)]

        letters = []
        for j in range(len(result_parts[0])):
            for i in range(period):
                if j < len(result_parts[i]):
                    letters.append(result_parts[i][j])

        return ''.join(letters)

    def encrypt(self, string):
        return self.process_string(string)

    def decrypt(self, string):
        return self.process_string(string, -1)

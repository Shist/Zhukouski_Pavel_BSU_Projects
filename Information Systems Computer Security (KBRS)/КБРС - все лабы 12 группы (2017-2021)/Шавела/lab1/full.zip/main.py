from vigenere import Vigenere
from kasiski import Kasiski
from frequency_analysis import Analyzer
import matplotlib.pyplot as plt

KEY_WORD = 'CAT'

KEY_WORDS = [
    'ME',
    'DOG',
    'MORE',
    'TODAY',
    'SOURCE',
    'ALGEBRA',
    'ACTUALLY',
    'YESTERDAY',
    'ABBREVIATE',
    'BUSINESSMAN'
]

TEXT_PORTIONS = [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1]

REPORT_COLUMN_NAMES = [
    'TEXT LENGTH',
    'REAL KEYWORD',
    'RK LENGTH',
    'SUGGESTED KEYWORD',
    'SK LENGTH',
    'SUCCESS RATE'
]

FIXED_KEY_GRAPHICS = []                 # text length and percent
FIXED_TEXT_GRAPHICS = []                # show key length and percent

with open('small_text.txt') as text_file:
    small_text = text_file.read()

with open('big_text.txt') as text_file:
    big_text = text_file.read()

report = open('report.txt', 'w')

TEXT_LENGTHS = [int(tp * len(big_text)) for tp in TEXT_PORTIONS]

kasiski = Kasiski(3)


def count_success_rate(keyword, found_keyword):
    length = len(keyword)
    finded_len = len(found_keyword)
    count = [
        (i < finded_len and found_keyword[i] == el)
        for i, el in enumerate(keyword)
    ].count(True)
    return int(100 * count / length)


def print_table_row(*args):
    report.write('|'.join(map(str, args)) + '\n')


def print_table(title):
    report.write(title + '\n')
    print_table_row(*REPORT_COLUMN_NAMES)


def print_test(text_len, keyword, found_keyword):
    percent = count_success_rate(keyword, found_keyword)
    print_table_row(text_len, keyword, len(keyword), found_keyword, len(found_keyword), '{}%'.format(percent))
    return percent


def run_test(text, keyword):
    encrypted = Vigenere(keyword).encrypt(text)
    analyzer = Analyzer(kasiski.get_key_len(encrypted))
    found_keyword = analyzer.find_keyword(encrypted).upper()
    return print_test(len(text), keyword, found_keyword)


def run_all_tests():
    report.write('REPORT\n')

    print_table('\nTEST 1: fixed KEYWORD length\n')
    percents = []
    text_lens = []
    for text_len in TEXT_LENGTHS:
        percents.append(run_test(big_text[:text_len], KEY_WORDS[6]))
        text_lens.append(text_len)
    fig, ax = plt.subplots()
    ax.plot(text_lens, percents)
    plt.title('TEST 1: fixed KEYWORD length')
    plt.text(5000, 20, 'Keyword length = 6')
    plt.xlabel('Text length')
    plt.ylabel('Success percent')
    plt.ylim(0, 110)
    plt.show()

    print_table('\nTEST 2: fixed TEXT length\n')
    percents = []
    for keyword in KEY_WORDS:
        percents.append(run_test(big_text[:7000], keyword))
    fig, ax = plt.subplots()
    ax.plot((2, 3, 4, 5, 6, 7, 8, 9, 10, 11), percents)
    plt.title('TEST 2: fixed TEXT length')
    plt.text(2.5, 20, 'Text length = 7000')
    plt.xlabel('Keyword length')
    plt.ylabel('Success percent')
    plt.ylim(0, 110)
    plt.show()


if __name__ == '__main__':
    vigenere = Vigenere(KEY_WORD)
    encrypted = vigenere.encrypt(small_text)
    decrypted = vigenere.decrypt(encrypted)
    print('VIGENERE CIPHER')
    print('\nText:\n\n' + small_text)
    print('\nEncrypted text:\n\n' + encrypted)
    print('\nDecrypted text:\n\n' + decrypted)

    length = Kasiski(3).get_key_len(encrypted)
    print('\nKASISKI ATTACK')
    print('\nKeyword length: ' + str(length))

    keyword = Analyzer(length).find_keyword(encrypted)
    print('Found keyword: ' + keyword.upper())

    run_all_tests()
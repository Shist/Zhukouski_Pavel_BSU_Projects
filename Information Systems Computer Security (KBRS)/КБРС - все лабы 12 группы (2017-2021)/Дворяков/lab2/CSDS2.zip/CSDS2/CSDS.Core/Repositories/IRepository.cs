﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using CSDS.Core.Entities;

namespace CSDS.Core.Repositories
{
    public interface IRepository<TEntity, in TKey> where TEntity : Entity<TKey>
    {
        TEntity Find(TKey id, string includeProperties = "", bool track = false);
        IEnumerable<TEntity> List(Expression<Func<TEntity, bool>> predicate = null,
            Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null,
            string includeProperties = "", bool track = false);

        void Add(TEntity item);
        void Remove(TEntity entity);
    }
}

import java.io.*;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Scanner;

public class Reader {
    public static String ReadFromFile(String f) throws FileNotFoundException {
        String s ="";

        Scanner input = new Scanner(f);

        File file = new File(input.nextLine());

        input = new Scanner(file);
        while (input.hasNextLine()) {
            String line = input.nextLine();
            s+=line;
        }
        input.close();

        return s;
    }
    public static void writeFile(String path, String s) {
        try {
            Files.write(Paths.get(path), s.getBytes(Charset.defaultCharset()));
        } catch (IOException e) {
            System.err.println("File is not exist!");
        }
    }
}

package com.example.kbrs

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class LoginActivity : AppCompatActivity() {

    lateinit var button: Button
    lateinit var emailTV: TextView
    lateinit var passwordTV: TextView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        button = findViewById<Button>(R.id.button2)
        emailTV = findViewById<TextView>(R.id.editTextTextEmail)
        passwordTV = findViewById<TextView>(R.id.editTextTextPassword)

        GlobalScope.launch {
            button.setOnClickListener {
                val email = emailTV.text
                val password = passwordTV.text
                if (email == "daniilshkurski@gmail.com" && password == "12345678") {
                    val intent = Intent(this@LoginActivity, Factor2Activity::class.java)
                    startActivity(intent)
                    finish()
                }
            }
        }

    }
}
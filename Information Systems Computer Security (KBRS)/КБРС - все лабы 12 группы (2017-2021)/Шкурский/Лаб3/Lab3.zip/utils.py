import random


class Curve:
    def __init__(self, m, a, b):
        self.m = m
        self.a = a
        self.b = b

    def res(self, _x: int):
        for _y in range(self.m):
            if (_y * _y) % self.m == ((_x ** 3 + self.a * _x + self.b) % self.m):
                return [_y] if _y == 0 else [_y, self.m - _y]
        return []

if __name__ == '__main__':
    c = Curve(67, 1, 0)
    points = []
    for x in range(c.m):
        y = c.res(x)
        points.extend(zip([x, x], y))
    group_order = len(points) + 1
    print(points)
    print(f'Order of group: {group_order}')
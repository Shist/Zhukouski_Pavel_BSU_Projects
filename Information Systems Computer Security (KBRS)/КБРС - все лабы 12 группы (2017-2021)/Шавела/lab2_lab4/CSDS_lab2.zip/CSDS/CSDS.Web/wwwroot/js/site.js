﻿$(document).on("click", ".model-popup", onClickShowModal);

var iv = [21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36];

function b64ToBn(b64) {
    var bin = atob(b64);
    var hex = [];

    bin.split('').forEach(function (ch) {
        var h = ch.charCodeAt(0).toString(16);
        if (h.length % 2) { h = '0' + h; }
        hex.push(h);
    });

    return hex.join('').toUpperCase();
}

function base64ToHex(str) {
    const raw = atob(str);
    let result = '';
    for (let i = 0; i < raw.length; i++) {
        const hex = raw.charCodeAt(i).toString(16);
        result += (hex.length === 2 ? hex : '0' + hex);
    }
    return result.toUpperCase();
}

function toHexString(byteArray) {
    return Array.prototype.map.call(byteArray, function (byte) {
        return ('0' + (byte & 0xFF).toString(16)).slice(-2);
    }).join('').toUpperCase();
}

function toByteArray(x) {
    var hexString = x.toString(16);
    if (hexString.length % 2 > 0) hexString = "0" + hexString;
    var byteArray = [];
    for (var i = 0; i < hexString.length; i += 2) {
        byteArray.push(parseInt(hexString.slice(i, i + 2), 16));
    }
    return byteArray;
}

String.prototype.hexEncode = function () {
    var hex, i;

    var result = "";
    for (i = 0; i < this.length; i++) {
        hex = this.charCodeAt(i).toString(16);
        result += ("000" + hex).slice(-4);
    }

    return result
}

function hexStringToByte(str) {
    if (!str) {
        return new Uint8Array();
    }

    var a = [];
    for (var i = 0, len = str.length; i < len; i += 2) {
        a.push(parseInt(str.substr(i, 2), 16));
    }

    return new Uint8Array(a);
}

function _base64ToArrayBuffer(base64) {
    var binary_string = window.atob(base64);
    var len = binary_string.length;
    var bytes = new Uint8Array(len);
    for (var i = 0; i < len; i++) {
        bytes[i] = binary_string.charCodeAt(i);
    }
    return bytes.buffer;
}

function convertToHex(str) {
    var hex = '';
    for (var i = 0; i < str.length; i++) {
        hex += '' + str.charCodeAt(i).toString(16);
    }
    return hex;
}

function getKey(data) {
    var rsa = new RSAKey();
    rsa.setPrivateEx(b64ToBn(data.privateKey.modulus), b64ToBn(data.privateKey.exponent), b64ToBn(data.privateKey.d), b64ToBn(data.privateKey.p), b64ToBn(data.privateKey.q), b64ToBn(data.privateKey.dp), b64ToBn(data.privateKey.dq), b64ToBn(data.privateKey.inverseQ));
    var res = rsa.decrypt(data.sessionKey);

    return res;
}

function getCookie(name) {
    var cookieArr = document.cookie.split(";");

    for (var i = 0; i < cookieArr.length; i++) {
        var cookiePair = cookieArr[i].split("=");

        if (name == cookiePair[0].trim()) {
            return decodeURIComponent(cookiePair[1]);
        }
    }

    return null;
}

function vigenere(key, str, mode) {
    var output = [str.length];
    var result = 0;
    var output_str;

    for (var i = 0; i < str.length; i++) {
        if (mode == 1) {
            result = ((str.charCodeAt(i) + key.charCodeAt(i % key.length)) % 128);
            output[i] = String.fromCharCode(result);
            console.log(
                str[i], key[i], result, output[i])

        } else if (mode == 0) {
            if (str.charCodeAt(i) - key.charCodeAt(i % key.length) < 0) {
                result = (str.charCodeAt(i) - key.charCodeAt(i % key.length)) + 128;
            } else {
                result = (str.charCodeAt(i) - key.charCodeAt(i % key.length)) % 128;
            }
            output[i] = String.fromCharCode(result);
        }

    }
    output_str = output.join('');
    return output_str;
}

function ApplayPassword(event) {
    var password = $("#SpecPassword").val();
    var text = $("#text").val();
    var encrypted = vigenere(password, text, 1);
    $("#text").val(encrypted);
}

function ApplayDecrypt(event) {
    var password = $("#SpecPassword").val();
    var text = $("#text-edit").val();
    $("#text-edit").val(vigenere(password, text, 0));
}

$("#login").submit(function (event) {
    var text = $("#password").val();
    var number = parseInt(getCookie("auth"));
    var hexValue = text;
    for (let i = 0; i < number - 1; i++) {
        var hash = sha256.create();
        hash.update(hexValue);
        hexValue = hash.hex();
    }
    console.log(hexValue);
    $("#password").val(hexValue);
});

$("#add-text").submit(function (event) {
    $.ajax({
        type: 'GET',
        url: '/crypto',
        dataType: 'json',
        async: false,
        success: function (data) {
            var key = getKey(data);

            var bytes = [];
            for (var i = 0; i < data.privateKey.k.length; ++i) {
                var code = data.privateKey.k.charCodeAt(i);
                bytes = bytes.concat([code & 0xff, code / 256 >>> 0]);
            }

            var decryptedKey = bytes;

            var text = $("#text").val();
            var textBytes = aesjs.utils.utf8.toBytes(text);
            var aesOfb = new aesjs.ModeOfOperation.ofb(decryptedKey, iv);
            var encryptedBytes = aesOfb.encrypt(textBytes);

            $("#text").val(encryptedBytes);
        }
    });
});

function EditText(event) {
    $.ajax({
        type: 'GET',
        url: '/crypto',
        dataType: 'json',
        async: false,
        success: function (data) {
            var key = getKey(data);

            var bytes = [];
            for (var i = 0; i < data.privateKey.k.length; ++i) {
                var code = data.privateKey.k.charCodeAt(i);
                bytes = bytes.concat([code & 0xff, code / 256 >>> 0]);
            }

            var decryptedKey = bytes;

            
            var password = $("#SpecPassword").val();
            var text = $("#text-edit").val();
            text = vigenere(password, text, 1);
            var textBytes = aesjs.utils.utf8.toBytes(text);
            var aesOfb = new aesjs.ModeOfOperation.ofb(decryptedKey, iv);
            var encryptedBytes = aesOfb.encrypt(textBytes);

            $("#text-edit").val(encryptedBytes);
        }
    });
    }

$("#edit-text").ready(function (event) {
    element = document.getElementById("text-edit");
    if (element != null) {
        $.ajax({
            type: 'GET',
            url: '/crypto',
            dataType: 'json',
            async: false,
            success: function (data) {
                var key = getKey(data);

                var bytes = [];
                for (var i = 0; i < data.privateKey.k.length; ++i) {
                    var code = data.privateKey.k.charCodeAt(i);
                    bytes = bytes.concat([code & 0xff, code / 256 >>> 0]);
                }

                var decryptedKey = bytes;

                var text = $("#text-edit").val();
                console.log($("#text-edit").val());
                var aesOfb = new aesjs.ModeOfOperation.ofb(decryptedKey, iv);
                var decryptedBytes = aesOfb.decrypt(aesjs.utils.hex.toBytes(text));

                $("#text-edit").val(aesjs.utils.utf8.fromBytes(decryptedBytes));
            }
        });
    }
});

function onClickShowModal(event) {
    event.preventDefault();
    console.log(this.href);
    $.get(this.href,
        function (data) {
            $("#dialogContent").html(data);
            if (data.indexOf('<h3 style="float: left;">List of courses</h3>') != -1) {
                $.ajax({
                    type: 'GET',
                    url: 'List/',
                    success: function (data) {
                        $("body").html(data);
                    }
                });
            } else {
                $("#modDialog").modal("show");
            }

        });
}

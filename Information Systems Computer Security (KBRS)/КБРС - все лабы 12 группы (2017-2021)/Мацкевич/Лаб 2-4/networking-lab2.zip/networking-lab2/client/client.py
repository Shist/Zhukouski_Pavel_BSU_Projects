import socket
from getpass import getpass
import sys
sys.path.append('./libs')

import client_storage
from common import crypt
from common.crypt import encrypt_aes
from common.socket_util import Socket, PLAIN_TEXT, AES_ENCODED, decode_utf8, NO_INPUT, SUCCESS, REFRESH, encode_utf8


class Client:
    def __init__(self, address: str, port: int):
        self.aes_key = None
        self.address = address
        self.port = port
        self.sock = None

    def start(self):
        client_storage.gen_rsa()
        self.sock = Socket(socket.create_connection((self.address, self.port)))
        if self.auth(is_first=True):
            self.receive_loop()

    def receive_loop(self):
        from client_command import perform_by_name

        while True:
            response = self.sock.recv()
            if response.response_code == REFRESH:
                self.auth()
                continue
            if response.response_code != SUCCESS:
                print(decode_utf8(response.body))
                print("Response code: {}".format(response.response_code))
                continue
            if response.encoded_flag == PLAIN_TEXT:
                if response.body[0] == 33:
                    perform_by_name(response.body, self)
                    continue
                else:
                    print(decode_utf8(response.body))
            elif response.encoded_flag == AES_ENCODED:
                print(decode_utf8(crypt.decrypt_aes(self.aes_key, response.body)))
            else:
                print(response.body)
            if response.input_wanted_flag == NO_INPUT:
                continue
            self.sock.send_string(input())

    def auth(self, is_first=False, is_refresh=False):
        pub, private = client_storage.get_rsa_pair()
        if is_first:
            self.sock.send(pub)
        aes_key_coded = self.sock.recv().body
        self.aes_key = crypt.decrypt_rsa(private, aes_key_coded)
        if is_first:
            print(decode_utf8(self.sock.recv().body))
            authtype = input()
            self.sock.send_string(authtype)
            print(decode_utf8(self.sock.recv().body))
            username = input()
            self.sock.send_string(username)
        print(decode_utf8(self.sock.recv().body))
        password = getpass()
        self.sock.send(encrypt_aes(self.aes_key, encode_utf8(password)))
        response = self.sock.recv()
        if response.response_code != SUCCESS:
            print("Failed to authenticate.")
            self.sock.close()
            return False
        return True


if __name__ == '__main__':
    Client('server', 8080).start()

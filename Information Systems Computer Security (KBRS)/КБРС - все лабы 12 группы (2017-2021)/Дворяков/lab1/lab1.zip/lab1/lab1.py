import matplotlib.pyplot as plt

from ciphers import Vigenere
from hackers import Kasiski, Analyzer

with open('text.txt') as data_file:
    data_small = data_file.read()

with open('big.txt') as data_file:
    data_big = data_file.read()

KEY_WORD = 'KEY'
report = open('report.txt', 'w')

VIGENERE_KEY_WORDS = [
    'AS',
    'KEY',
    'SORT',
    'FORCE',
    'SECRET',
    'COLORED',
    'ABSTRACT',
    'YESTERDAY',
    'FLYCATCHER',
    'OPPOSITIONS'
]
PERCENTS = [0.04, 0.05, 0.1, 0.2, 0.35, 0.5, 0.7, 0.8, 0.9, 1]
TEXT_LENGTHS = [int(p * len(data_big)) for p in PERCENTS]
TABLE_COLS = [
    'text len',
    'keyword',
    'len',
    'found keyword',
    'len',
    'success probability'
]

def count_percent(keyword, found_keyword):
    length = len(keyword)
    finded_len = len(found_keyword)
    count = [
        (i < finded_len and found_keyword[i] == el)
        for i, el in enumerate(keyword)
    ].count(True)
    return int(100 * count / length)

def print_table_row(*args):
    report.write('|'.join(map(str, args)) + '\n')

def print_table(title):
    report.write(title + '\n')
    print_table_row(*TABLE_COLS)

def print_test(text_len, keyword, found_keyword):
    percent = count_percent(keyword, found_keyword)
    print_table_row(text_len, keyword, len(keyword), found_keyword, len(found_keyword), '{}%'.format(percent))
    return percent

def run_test(text, keyword):
    encrypted = Vigenere(keyword).encrypt(text)
    analyzer = Analyzer(Kasiski(3).get_len(encrypted))
    finded_keyword = analyzer.find_keyword(encrypted).upper()
    return print_test(len(text), keyword, finded_keyword)

def run():
    report.write('Report\n')

    print_table('test 1: with fixed keyword length')
    percents = []
    for text_len in TEXT_LENGTHS:
        percents.append(run_test(data_big[:text_len], VIGENERE_KEY_WORDS[6]))

    print_table('test 2: with fixed text length')
    percents = []
    for keyword in VIGENERE_KEY_WORDS:
        percents.append(run_test(data_big[:6000], keyword))

if __name__ == '__main__':
    vigenere = Vigenere(KEY_WORD)
    encrypted = vigenere.encrypt(data_small)
    decrypted = vigenere.decrypt(encrypted)
    print('data: ' + data_small)
    print('encrypted: ' + encrypted)
    print('decrypted: ' + decrypted)
    print('-' * 200)

    length = Kasiski(3).get_len(encrypted)
    print('Kasiski:')
    print('keyword length: ' + str(length))

    keyword = Analyzer(length).find_keyword(encrypted)
    print('found keyword: ' + keyword.upper())
    print('-' * 200)

    run()
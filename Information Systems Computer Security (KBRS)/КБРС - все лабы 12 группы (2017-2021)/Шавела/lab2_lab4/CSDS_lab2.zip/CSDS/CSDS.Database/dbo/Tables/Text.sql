﻿CREATE TABLE [dbo].[Text]
(
    [Id] UNIQUEIDENTIFIER NOT NULL,
    [Name] NVARCHAR(1024) NOT NULL,
    [Content] NVARCHAR(MAX) NULL,
    [UserId] UNIQUEIDENTIFIER NOT NULL,
    CONSTRAINT [PK_dbo_Text] PRIMARY KEY ([Id]),
    CONSTRAINT [FK_dbo_Text_User_Id] FOREIGN KEY ([UserId]) REFERENCES [dbo].[User]([Id])
)
﻿using System.Collections.Generic;
using CSDS.Core.Entities;

namespace CSDS.Web.Models
{
    public class TextListViewModel
    {
        public IEnumerable<Text> Texts { get; set; }

        public PageViewModel PageViewModel { get; set; }

        public int Page { get; set; } = 1;
    }
}

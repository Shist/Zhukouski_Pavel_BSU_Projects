﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using CSDS.ApplicationServices.Interfaces;
using CSDS.Core.Entities;
using CSDS.Core.Repositories;
using CSDS.Web.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace CSDS.Web.Controllers
{
    [Authorize(Roles = "Full")]
    public class TextController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly ICryptoService _cryptoService;

        private readonly int _pageSize = 5;

        public TextController(IUnitOfWork unitOfWork, ICryptoService cryptoService)
        {
            _unitOfWork = unitOfWork;
            _cryptoService = cryptoService;
        }

        [Route("")]
        public ActionResult List(TextListViewModel model)
        {
            var principal = HttpContext.User;
            var claimUser = principal.Claims.FirstOrDefault(x => x.Type == "userId");

            if (claimUser == null) return NotFound();

            var list = new List<Expression<Func<Text, bool>>> {x => x.UserId == Guid.Parse(claimUser.Value)};
            var (texts, count) = _unitOfWork.TextRepository.PagingList(model.Page, _pageSize, list);

            var pageViewModel = new PageViewModel(count, model.Page, _pageSize);
            model.PageViewModel = pageViewModel;
            model.Texts = texts;

            return View(model);
        }

        [HttpGet("[controller]/[action]")]
        public IActionResult Add()
        {
            var model = new TextEditModel
            {
                Id = Guid.NewGuid(),
            };

            return View(model);
        }

        [HttpPost("[controller]/[action]")]
        public IActionResult Add(TextEditModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var principal = HttpContext.User;
            var claimUser = principal.Claims.FirstOrDefault(x => x.Type == "userId");
            var claimKey = principal.Claims.FirstOrDefault(x => x.Type == "key");

            if (claimUser == null) return NotFound();
            if (claimKey == null) return NotFound();

            var words = (string.IsNullOrWhiteSpace(model.Content) ? null : model.Content)?.Split(new char[] { ',' });

            var bytes = words?.Select(byte.Parse).ToArray();

            var encrypted = _cryptoService.DecryptStringFromBytes_Aes(BitConverter.ToString(bytes).Replace("-", string.Empty),
                BitConverter.ToString(Encoding.Unicode.GetBytes(claimKey.Value)).Replace("-", string.Empty));

            _unitOfWork.TextRepository.Add(new Text
            {
                Name = model.Name,
                Content = encrypted,
                UserId = Guid.Parse(claimUser.Value)
            });

            _unitOfWork.Commit();

            return RedirectToAction("List");
        }

        [HttpGet("[controller]/[action]/{id:guid}")]
        public IActionResult Delete(Guid id)
        {
            var text = _unitOfWork.TextRepository.Find(id);
            if (text == null) return NotFound();

            var model = new TextEditModel {Id = id, Name = text.Name, Content = text.Content};

            return PartialView("ConfirmTextDelete", model);
        }

        [HttpPost("[controller]/[action]/{id:guid}")]
        public IActionResult Delete(TextEditModel model)
        {
            var text = _unitOfWork.TextRepository.Find(model.Id);
            if (text == null) return NotFound();

            _unitOfWork.TextRepository.Remove(text);

            _unitOfWork.Commit();

            return RedirectToAction("List");
        }

        [HttpGet("[controller]/[action]/{id:guid}")]
        public IActionResult Edit(Guid id)
        {
            var text = _unitOfWork.TextRepository.Find(id);
            if (text == null) return NotFound();


            var principal = HttpContext.User;
            var claim = principal.Claims.FirstOrDefault(x => x.Type == "key");

            if (claim == null) return NotFound();

            var decrypted = _cryptoService.EncryptStringToBytes_Aes(text.Content, BitConverter.ToString(Encoding.Unicode.GetBytes(claim.Value)).Replace("-", string.Empty));

            var model = new TextEditModel
            {
                Id = text.Id,
                Name = text.Name,
                Content = decrypted
            };

            return View(model);

        }

        [HttpPost("[controller]/[action]/{id:guid}")]
        public IActionResult Edit(TextEditModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var text = _unitOfWork.TextRepository.Find(model.Id, track: true);
            if (text == null) return NotFound();

            var principal = HttpContext.User;
            var claimKey = principal.Claims.FirstOrDefault(x => x.Type == "key");

            if (claimKey == null) return NotFound();

            var words = (string.IsNullOrWhiteSpace(model.Content) ? null : model.Content)?.Split(new char[] { ',' });

            var bytes = words?.Select(byte.Parse).ToArray();

            var encrypted = _cryptoService.DecryptStringFromBytes_Aes(BitConverter.ToString(bytes).Replace("-", string.Empty),
                BitConverter.ToString(Encoding.Unicode.GetBytes(claimKey.Value)).Replace("-", string.Empty));

            text.Name = model.Name;
            text.Content = encrypted;

            _unitOfWork.Commit();

            return RedirectToAction("List");
        }
    }
}

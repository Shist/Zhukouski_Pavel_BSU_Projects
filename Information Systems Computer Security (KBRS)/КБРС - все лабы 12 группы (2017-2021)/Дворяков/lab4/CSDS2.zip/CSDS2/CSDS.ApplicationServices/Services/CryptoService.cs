﻿using CSDS.ApplicationServices.Interfaces;
using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using NETCore.Encrypt;

namespace CSDS.ApplicationServices.Services
{
    public class CryptoService : ICryptoService
    {
        private readonly byte[] IV = { 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36 };

        private readonly byte[] PublicKey = { 2, 56, 213, 178, 125, 147, 119, 195, 18, 225, 204, 176, 91, 215, 85, 144, 161, 194, 62, 63, 158, 91, 1, 86, 137, 247, 183, 253, 148, 101, 210, 61 };

        public string EncryptStringToBytes_Aes(string plainText, string key)
        {
            if (plainText == null || plainText.Length <= 0)
                throw new ArgumentNullException("plainText");
            if (key == null || key.Length <= 0)
                throw new ArgumentNullException("Key");
            if (IV == null || IV.Length <= 0)
                throw new ArgumentNullException("IV");

            var crypt = new Chilkat.Crypt2
            {
                CryptAlgorithm = "aes", 
                CipherMode = "ofb", 
                KeyLength = 128,
                IV = IV,
                EncodingMode = "hex"
            };

            crypt.SetEncodedKey(key, "hex");

            return crypt.EncryptStringENC(plainText);
        }

        public string DecryptStringFromBytes_Aes(string cipherText, string key)
        {
            if (cipherText == null || cipherText.Length <= 0)
                throw new ArgumentNullException("cipherText");
            if (key == null || key.Length <= 0)
                throw new ArgumentNullException("Key");
            if (IV == null || IV.Length <= 0)
                throw new ArgumentNullException("IV");

            var decrypt = new Chilkat.Crypt2
            {
                CryptAlgorithm = "aes", 
                CipherMode = "ofb", 
                KeyLength = 128,
                IV = IV,
                EncodingMode = "hex"
            };

            decrypt.SetEncodedKey(key, "hex");

            return decrypt.DecryptStringENC(cipherText);
        }

        public byte[] RSAEncrypt(byte[] DataToEncrypt, RSAParameters RSAKeyInfo, bool DoOAEPPadding)
        {
            try
            {
                byte[] encryptedData;

                using (var RSA = new RSACryptoServiceProvider())
                {
                    RSA.ImportParameters(RSAKeyInfo);

                    encryptedData = RSA.Encrypt(DataToEncrypt, DoOAEPPadding);
                }
                return encryptedData;
            }
            catch (CryptographicException e)
            {
                return null;
            }
        }

        public byte[] RSADecrypt(byte[] DataToDecrypt, RSAParameters RSAKeyInfo, bool DoOAEPPadding)
        {
            try
            {
                byte[] decryptedData;

                using (var RSA = new RSACryptoServiceProvider())
                {
                    RSA.ImportParameters(RSAKeyInfo);

                    decryptedData = RSA.Decrypt(DataToDecrypt, DoOAEPPadding);
                }
                return decryptedData;
            }
            catch (CryptographicException e)
            {
                return null;
            }
        }
    }
}

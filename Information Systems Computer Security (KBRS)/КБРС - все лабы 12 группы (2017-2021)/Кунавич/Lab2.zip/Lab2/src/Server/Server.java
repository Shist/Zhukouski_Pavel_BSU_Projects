package Server;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.SimpleFormatter;
import java.util.*;
import java.security.*;


/**
 * Обеспечивает работу программы в режиме сервера
 *
 * @author
 */
public class Server {
    final String text1 = "When be draw drew ye. Defective in do recommend suffering. House it seven in spoil tiled court. Sister others marked fat missed did out use. Alteration possession dispatched collecting instrument travelling he or on. Snug give made at spot or late that mr. ";
    final String text2 = "He my polite be object oh change. Consider no mr am overcame yourself throwing sociable children. Hastily her totally conduct may. My solid by stuff first smile fanny. Humoured how advanced mrs elegance sir who. Home sons when them dine do want to. Estimating themselves unsatiable imprudence an he at an. Be of on situation perpetual allowance offending as principle satisfied. Improved carriage securing are desirous too. ";
    final String text3 = "Not far stuff she think the jokes. Going as by do known noise he wrote round leave. Warmly put branch people narrow see. Winding its waiting yet parlors married own feeling. Marry fruit do spite jokes an times. Whether at it unknown warrant herself winding if. Him same none name sake had post love. An busy feel form hand am up help. Parties it brother amongst an fortune of. Twenty behind wicket why age now itself ten. ";
    final int Port = 8000;
    private List<Connection> connections = new ArrayList<Connection>();
    private ServerSocket server;
    private Logger logger;

    /**
     * Конструктор создаёт сервер. Затем для каждого подключения создаётся
     * объект Connection и добавляет его в список подключений.
     */
    public Server() {
        try {
            logger = new Logger();
            server = new ServerSocket(Port);
            System.out.println("Server created successful");
            logger.info("Server created successful");

            while (true) {
                System.out.println("Waiting for connections...");
                Socket socket = server.accept();

                Connection con = new Connection(socket);
                connections.add(con);
                con.start();

                System.out.println("Connection was successful!");
                System.out.println("IP: " + socket.getInetAddress() + ":" + socket.getPort());
                logger.info("Connection done. IP: " + socket.getInetAddress() + ":" + socket.getPort());

            }
        } catch (IOException e) {}
        finally {
            closeAll();
        }
    }

    /**
     * Закрывает все потоки всех соединений а также серверный сокет
     */
    private void closeAll() {
        try {
            server.close();
            synchronized(connections) {
                Iterator<Connection> iter = connections.iterator();
                while(iter.hasNext()) {
                    iter.next().close();
                }
            }
        } catch (Exception e) {
            System.err.println("Threads were not closed!");
            logger.severe(e.getMessage());
        }
    }

    /**
     * Класс содержит данные, относящиеся к конкретному подключению:
     * <ul>
     * <li>имя пользователя</li>
     * <li>сокет</li>
     * <li>входной поток BufferedReader</li>
     * <li>выходной поток PrintWriter</li>
     * </ul>
     * Расширяет Thread и в методе run() получает информацию от пользователя и
     * пересылает её другим
     */
    private class Connection extends Thread {
        private BufferedReader in;
        private PrintWriter out;
        private Socket socket;
        private String name = "";

        /**
         * Конструктор, получает поля объекта и имя пользователя
         *
         * @param socket
         *            сокет, полученный из server.accept()
         */
        public Connection(Socket socket) {
            this.socket = socket;

            try {
                in = new BufferedReader(new InputStreamReader(
                        socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);

            } catch (IOException e) {
                e.printStackTrace();
                logger.severe(e.getMessage());
                close();
            }
        }
        public String IDEA(String text, int k) {
            String str = "";
            for(int i = 0; i< text.length();i++) {
                char ch = text.charAt(i);
                ch = (char) (text.charAt(i)+k);
                str+=ch;

            }
            return str;
        }
        /**
         * Запрашивает имя пользователя и ожидает от него сообщений. При
         * получении каждого сообщения, оно вместе с именем пользователя
         * пересылается всем остальным.
         */
        @Override
        public void run() {
            try {
                Random rand = new Random();
                name = in.readLine();
                System.out.println("Hello " + name);
                String str = "";
                str = in.readLine();
                logger.info("Server received RSA key");
                logger.info("RSA key: " + str);
                KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
                keyPairGenerator.initialize(2048);
                KeyPair keyPair = keyPairGenerator.generateKeyPair();
                PublicKey publicKey = keyPair.getPublic();
                int key = rand.nextInt();
                logger.info("Server generated key");
                str = in.readLine();
                logger.info("Server received text title");
                logger.info("Text title: " + str);
                String text = null;
                if(str.equals("text1")) {
                    text = text1;
                } else if (str.equals("text2")) {
                    text = text2;
                } else {
                    text = text3;
                }
                String criptText = IDEA(text,5);
                String criptKey = "";
                out.println();
                out.println(criptKey);
                out.println(criptText);
                str = in.readLine();
                System.out.println("Accepted : " + str);
            } catch (IOException | NoSuchAlgorithmException e) {
                e.printStackTrace();
                logger.severe(e.getMessage());
            } finally {
                close();
            }
        }

        /**
         * Закрывает входной и выходной потоки и сокет
         */
        public void close() {
            try {
                String ip = socket.getInetAddress() + ":" + socket.getPort();
                in.close();
                out.close();
                socket.close();

                connections.remove(this);
                System.out.println("Disconnected (IP: " + ip + ")");
                logger.info("Disconnected (IP: " + ip + ")");
                if (connections.size() == 0) {
                    Server.this.closeAll();
                    logger.info("Server closing...");
                    System.exit(0);
                }
            } catch (Exception e) {
                System.err.println("Threads were not closed!");
                logger.severe(e.getMessage());
            }
        }
    }

    private class Logger {
        private java.util.logging.Logger log;

        /**
         * Конструктор логгера
         */
        public Logger() {
            log = java.util.logging.Logger.getLogger(Logger.class.getName());
            Handler fileHandler;
            try {
                fileHandler = new FileHandler("server_log%u.%g.txt", 1024 * 1024, 20);
                fileHandler.setFormatter(new SimpleFormatter());
                log.addHandler(fileHandler);
                fileHandler.setLevel(Level.ALL);
                log.setLevel(Level.ALL);
                log.config("Configuration done.");
            } catch (IOException exception) {
                log.log(Level.SEVERE, "Error occur in FileHandler.", exception);
            }
        }

        /**
         * Сообщение с уровнем INFO
         *
         * @param message сообщение
         */
        public void info(String message) {
            log.log(Level.INFO, message);
        }

        /**
         * Сообщение с уровнем SEVERE
         *
         * @param message сообщение
         */
        public void severe(String message) {
            log.log(Level.SEVERE, message);
        }
    }
}
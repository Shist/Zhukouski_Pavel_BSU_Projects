﻿using Microsoft.AspNetCore.Mvc;

namespace CSDS.Web.Controllers
{
    public class HomeController : Controller
    {
        [Route("[controller]/[action]")]
        public IActionResult Index() => View();
    }
}

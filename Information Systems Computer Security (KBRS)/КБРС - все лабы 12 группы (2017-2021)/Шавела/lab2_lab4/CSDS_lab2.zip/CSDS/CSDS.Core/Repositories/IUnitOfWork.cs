﻿using System;

namespace CSDS.Core.Repositories
{
    public interface IUnitOfWork : IDisposable
    {
        IUserRepository UserRepository { get; }
        ITextRepository TextRepository { get; }

        void Commit();
    }
}

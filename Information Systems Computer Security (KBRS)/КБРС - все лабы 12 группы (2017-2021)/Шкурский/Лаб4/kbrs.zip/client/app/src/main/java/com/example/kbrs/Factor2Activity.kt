package com.example.kbrs

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class Factor2Activity : AppCompatActivity() {

    lateinit var button: Button
    lateinit var codeTV: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_factor2)

        button = findViewById<Button>(R.id.button3)
        codeTV = findViewById<TextView>(R.id.factor2Code)

        GlobalScope.launch {
            button.setOnClickListener{
                if(codeTV.text == "432545") {
                    val intent = Intent(this@Factor2Activity, MainActivity::class.java)
                    startActivity(intent)
                    finish()
                }
            }
        }
    }
}
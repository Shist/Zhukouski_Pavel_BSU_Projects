﻿using CSDS.Web.Models;

namespace CSDS.Web.Areas.Api.Models
{
    public class CryptoModel
    {
        public string SessionKey { get; set; }
        public SettingsViewModel PrivateKey { get; set; }
        public string Key { get; set; }
    }
}

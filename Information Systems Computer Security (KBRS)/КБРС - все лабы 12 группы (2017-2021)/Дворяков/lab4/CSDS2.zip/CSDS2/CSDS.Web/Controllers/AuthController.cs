﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using CSDS.Core.Entities;
using CSDS.Core.Repositories;
using CSDS.Web.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace CSDS.Web.Controllers
{
    public class AuthController : Controller
    {
        private readonly IUnitOfWork _unitOfWork;

        public AuthController(IUnitOfWork unitOfWork) => _unitOfWork = unitOfWork;

        [Route("[action]")]
        public IActionResult Login(string returnUrl)
        {
            ViewData["ReturnUrl"] = returnUrl;
            return View();
        }


        [HttpPost("[action]")]
        public async Task<IActionResult> Login(string email, string password, string returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;

            if (string.IsNullOrEmpty(email))
            {
                ModelState.AddModelError("email", "Email cannot be empty");
            }
            else if (email.Length < 4 || email.Length > 128)
            {
                ModelState.AddModelError("email", "Email's length must be [4..128]");
            }

            if (string.IsNullOrEmpty(password))
            {
                ModelState.AddModelError("password", "Password cannot be empty");
            }
            else if (password.Length < 8 || password.Length > 128)
            {
                ModelState.AddModelError("password", "Password's length must be [8..128]");
            }

            if (!ModelState.IsValid)
            {
                return View();
            }

            var user = _unitOfWork.UserRepository.FindByEmail(email);
            if (user == null)
            {
                return View(LoginResult.IncorrectPassword);
            }

            var newPassword = password;
            using (var sha256 = new SHA256Managed())
            {
                var hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                var sb = new StringBuilder(hash.Length * 2);

                foreach (var b in hash)
                {
                    sb.Append(b.ToString("x2"));
                }

                password = sb.ToString().ToLower();
            }

            if (user.Password != password)
            {
                return View(LoginResult.IncorrectPassword);
            }

            user.Password = newPassword;

            _unitOfWork.Commit();

            if (Request.Cookies.ContainsKey("auth"))
            {
                var number = Convert.ToInt32(Request.Cookies["auth"]);
                number--;
                Response.Cookies.Append("auth", number.ToString(), new CookieOptions { Expires = DateTimeOffset.MaxValue });
            }

            Response.Cookies.Append("token", Guid.NewGuid().ToString());

            using var myAes = Aes.Create();
            myAes.KeySize = 128;

            var claims = new List<Claim>
            {
                new Claim("userId", user.Id.ToString()),
                new Claim(ClaimTypes.Name, $"{user.FirstName} {user.LastName}"),
                new Claim("key", Encoding.Unicode.GetString(myAes.Key)),
                string.IsNullOrEmpty(user.SecretKey) ? new Claim(ClaimTypes.Role, "NotFull") : new Claim(ClaimTypes.Role, "Full") 
            };

            var principal = new ClaimsPrincipal(new ClaimsIdentity(claims, "CSDSType"));
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal,
                new AuthenticationProperties { AllowRefresh = true });

            if (string.IsNullOrEmpty(returnUrl))
            {
                return RedirectToAction("List", "Text");
            }

            return Redirect(returnUrl);
        }

        [Authorize]
        [Route("[action]")]
        public async Task<IActionResult> Logoff()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Index", "Home");
        }
        
        [Route("[action]")]
        public async Task<IActionResult> Registration(string returnUrl)
        {
            ViewData["ReturnUrl"] = returnUrl;
            return PartialView("Registration");
        }

        [HttpPost("[action]")]
        public async Task<IActionResult> Registration(string email, string password, string firstName, string secondName, string returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;

            if (string.IsNullOrEmpty(email))
            {
                ModelState.AddModelError("email", "Email cannot be empty");
            }
            else if (email.Length < 4 || email.Length > 128)
            {
                ModelState.AddModelError("email", "Email's length must be [4..128]");
            }

            if (string.IsNullOrEmpty(password))
            {
                ModelState.AddModelError("password", "Password cannot be empty");
            }
            else if (password.Length < 8 || password.Length > 128)
            {
                ModelState.AddModelError("password", "Password's length must be [8..128]");
            }

            if (string.IsNullOrEmpty(firstName))
            {
                ModelState.AddModelError("firstName", "First Name cannot be empty");
            }
            else if (firstName.Length < 3 || firstName.Length > 128)
            {
                ModelState.AddModelError("firstName", "First Name's length must be [8..128]");
            }

            if (string.IsNullOrEmpty(secondName))
            {
                ModelState.AddModelError("secondName", "SecondName cannot be empty");
            }
            else if (secondName.Length < 3 || secondName.Length > 128)
            {
                ModelState.AddModelError("secondName", "Second Name's length must be [8..128]");
            }

            if (!ModelState.IsValid)
            {
                return View();
            }

            using (var sha256 = new SHA256Managed())
            {
                for (int i = 0; i < 1000; i++)
                {
                    var hash = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                    var sb = new StringBuilder(hash.Length * 2);

                    foreach (var b in hash)
                    {
                        sb.Append(b.ToString("x2"));
                    }

                    password = sb.ToString().ToLower();
                }
            }

            _unitOfWork.UserRepository.Add(new User
            {
                Id = Guid.NewGuid(),
                Email = email,
                FirstName = firstName,
                LastName = secondName,
                Password = password
            });

            _unitOfWork.Commit();

            Response.Cookies.Append("auth", "1000", new CookieOptions { Expires = DateTimeOffset.MaxValue});

            return RedirectToAction("Index", "Rules");
        }
    }
}

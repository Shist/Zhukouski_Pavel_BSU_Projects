﻿using System;
using CSDS.Core.Entities;

namespace CSDS.Core.Repositories
{
    public interface IUserRepository : IRepository<User, Guid>
    {
        User FindByEmail(string email);
    }
}

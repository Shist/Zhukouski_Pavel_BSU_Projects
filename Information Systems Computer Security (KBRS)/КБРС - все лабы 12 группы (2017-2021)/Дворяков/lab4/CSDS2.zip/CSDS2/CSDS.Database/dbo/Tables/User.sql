﻿CREATE TABLE [dbo].[User]
(
    [Id] UNIQUEIDENTIFIER NOT NULL,
    [Email] NVARCHAR(320) NOT NULL,
    [Password] NVARCHAR(128) NOT NULL,
    [SecretKey] NVARCHAR(MAX),
    [FirstName] NVARCHAR(128) NOT NULL,
    [LastName] NVARCHAR(128) NOT NULL
    CONSTRAINT [PK_dbo_User] PRIMARY KEY ([Id])
)
GO

CREATE INDEX [IX_dbo_User_Email] ON [dbo].[User]([Email]);
GO
import scala.annotation.tailrec
import scala.math.BigInt
import scala.io._

object Viziner extends App{

  val alphabet = "abcdefghijklmnopqrstuvwxyz"
  val viziner: Cypher = new Cypher(alphabet, "papichq")

  val textSource = Source.fromFile("src\\main\\resources\\text.txt")
  val text = textSource.mkString
  textSource.close()

  println(text.length)
//"cryptography and data security"
  val encoded = viziner.encode(text.toLowerCase)
  //println(viziner.decode(encoded))
  val analyser = CryptoAnalyser(encoded)._2
  //println(analyser)

  print(CryptoAnalyser.findKey(encoded, alphabet, analyser, 'e'))

}

class Cypher(alphabet: String, keyword: String) {

  def decode(encodedText: String): String = {
    val decodeString = getVizinerString(encodedText)
    encodedText
      .zip(decodeString)
      .map({
          case(char, decodeChar) => {
            if (char.isLetter) {
                val index = (alphabet.indexOf(char) - alphabet.indexOf(decodeChar)) % alphabet.length
                alphabet(if(index < 0) index + alphabet.length else index)
              }
            else char
          }
        }
      )
      .mkString
  }

  def encode(text: String): String = {
    val encodeString = getVizinerString(text)
    text
      .zip(encodeString)
      .map(
        {
          case (char, encodeChar) => {
            if (char.isLetter)
              alphabet((alphabet.indexOf(char) + alphabet.indexOf(encodeChar)) % alphabet.length)
            else char
          }
        }
      )
      .mkString
  }

  private def getVizinerString(text: String): String = {
    keyword * (text.length / keyword.length) + keyword.substring(0, text.length % keyword.length)
  }
}

object CryptoAnalyser {
  def apply(text: String): (Int, Int) = {
    val m = text.sliding(3)
    val res = m
      .toSet
      .map(substr => findOccurence(text, substr))
      .flatten
    res.filter(_._2 > 0).toList.maxBy(_._1)
  }

  def findOccurence(text: String, substr: String): Option[(Int, Int)] = {
    @tailrec def count(pos:Int, acc: List[Int]): List[Int] ={
      val idx = text indexOf(substr, pos)
      if(idx == -1) acc else count(idx + substr.length, idx :: acc)
    }
    val list =  count(0, Nil)

    if (list.length > 2) Some(list.length, list
        .sliding(2)
        .map(list => list.tail.head - list.head)
        .map(BigInt(_))
        .reduce(_.gcd(_))
        .toInt)
    else None
  }

  def analyserCaesar(text: String): Char = {
    text
      .toList
      .filter(_.isLetter)
      .groupBy(identity)
      .mapValues(_.length)
      .maxBy(_._2)
      ._1
  }

  def findKey(text: String, alphabet: String, length: Int, mostCommonChar: Char) : String = {
    text
      .toLowerCase()
      .grouped(length)
      .toList
      .dropRight(1)
      .map(_.toList.map(_.toString))
      .reduce(_.zip(_).map(elem => elem._1 +  elem._2))
      .map(
        {
          elem => {
            val index = (alphabet.indexOf(CryptoAnalyser.analyserCaesar(elem)) - alphabet.indexOf(mostCommonChar)) % alphabet.length
            alphabet(if (index < 0) index + alphabet.length else index).toString
          }
        })
      .reduce(_ + _)
  }

}
